import React, { useState, useMemo, useEffect } from 'react';
import {
  LayoutDashboard,
  FileText,
  FilePlus2,
  Users,
  Layers,
  Search,
  Plus,
  Trash2,
  Printer,
  CheckCircle2,
  Download,
  Calculator,
  Factory,
  ArrowUpRight,
  Building2,
  BarChart3,
  Settings,
  Smartphone,
  LogOut,
  DownloadCloud,
  Check,
  Upload,
  ShieldCheck,
  UserPlus,
  Pencil,
  ExternalLink,
} from 'lucide-react';
import {
  COMPANY_PROFILE,
  CompanyProfileConfig,
  INITIAL_CUSTOMERS,
  INITIAL_INVOICES,
  INITIAL_SERVICES,
  INITIAL_JOB_ORDERS,
  INITIAL_STAFF_USERS,
  Invoice,
  InvoiceLineItem,
  InvoiceStatus,
  Customer,
  CoatingService,
  JobOrder,
  StaffUser,
  UserRole,
  formatINR,
  numberToIndianRupeesWords,
} from './data/vdCoatingData';
import { InvoicePrintModal } from './components/InvoicePrintModal';
import { VdLogo, renderLogoToPngDataUrl } from './components/VdLogo';
import { usePWAInstall } from './hooks/usePWAInstall';
import { downloadInvoicePdf } from './utils/invoicePdfGenerator';

type ActiveTab =
  | 'dashboard'
  | 'invoices'
  | 'create-invoice'
  | 'customers'
  | 'services'
  | 'reports'
  | 'settings';

const STORAGE_KEYS = {
  INVOICES: 'vd_coating_invoices_v2',
  CUSTOMERS: 'vd_coating_customers_v2',
  SERVICES: 'vd_coating_services_v2',
  JOBS: 'vd_coating_jobs_v2',
  COMPANY: 'vd_coating_company_profile_v2',
  STAFF: 'vd_coating_staff_users_v2',
};

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const { isInstallable, isInstalled, isIOS, isInIframe, install } = usePWAInstall();
  const [showMobileSyncModal, setShowMobileSyncModal] = useState(() => {
    try {
      return new URLSearchParams(window.location.search).get('install') === '1';
    } catch {
      return false;
    }
  });

  // Editable Company Settings State (Persisted in localStorage)
  const [companyInfo, setCompanyInfo] = useState<CompanyProfileConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.COMPANY);
      return saved ? JSON.parse(saved) : COMPANY_PROFILE;
    } catch {
      return COMPANY_PROFILE;
    }
  });

  // Staff / Other User Access Control State (Persisted in localStorage)
  const [staffUsers, setStaffUsers] = useState<StaffUser[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.STAFF);
      return saved ? JSON.parse(saved) : INITIAL_STAFF_USERS;
    } catch {
      return INITIAL_STAFF_USERS;
    }
  });

  // New User Form State in Company Settings
  const [newUserName, setNewUserName] = useState('');
  const [newUserContact, setNewUserContact] = useState('');
  const [newUserRole, setNewUserRole] = useState<UserRole>('BILLING OPERATOR');

  // Persistent ERP State
  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.INVOICES);
      return saved ? JSON.parse(saved) : INITIAL_INVOICES;
    } catch {
      return INITIAL_INVOICES;
    }
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
      return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
    } catch {
      return INITIAL_CUSTOMERS;
    }
  });

  const [services, setServices] = useState<CoatingService[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SERVICES);
      return saved ? JSON.parse(saved) : INITIAL_SERVICES;
    } catch {
      return INITIAL_SERVICES;
    }
  });

  const [jobOrders, setJobOrders] = useState<JobOrder[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.JOBS);
      return saved ? JSON.parse(saved) : INITIAL_JOB_ORDERS;
    } catch {
      return INITIAL_JOB_ORDERS;
    }
  });

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(invoices));
    } catch {
      // Ignore storage quota errors
    }
  }, [invoices]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
    } catch {
      // Ignore
    }
  }, [customers]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(services));
    } catch {
      // Ignore
    }
  }, [services]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.JOBS, JSON.stringify(jobOrders));
    } catch {
      // Ignore
    }
  }, [jobOrders]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.COMPANY, JSON.stringify(companyInfo));
    } catch {
      // Ignore
    }
    // Dynamically sync browser favicon & phone home-screen apple-touch-icon with current logo
    renderLogoToPngDataUrl(companyInfo.logoUrl, 256).then((pngUrl) => {
      if (!pngUrl) return;
      const iconLinks = document.querySelectorAll("link[rel*='icon'], link[rel='apple-touch-icon']");
      iconLinks.forEach((link) => {
        (link as HTMLLinkElement).href = pngUrl;
      });
    });
  }, [companyInfo]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.STAFF, JSON.stringify(staffUsers));
    } catch {
      // Ignore
    }
  }, [staffUsers]);

  // Toast NotificationBanner
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  // Selected Invoice for Print/View Modal
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  // Invoice List Filter & Search State
  const [invoiceSearch, setInvoiceSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | InvoiceStatus>('ALL');

  // New Invoice Builder Form State
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(customers[0]?.id || '');
  const [customCustomerName, setCustomCustomerName] = useState<string>(customers[0]?.name || '');
  const [customCustomerGstin, setCustomCustomerGstin] = useState<string>(customers[0]?.gstin || '');
  const [customCustomerContact, setCustomCustomerContact] = useState<string>(
    customers[0]?.phone || '9822000000'
  );
  const [customCustomerAddress, setCustomCustomerAddress] = useState<string>(
    customers[0] ? `${customers[0].address}` : ''
  );

  // Ship To (Consignee) State with 'Same as Billed To' Tick Mark
  const [sameAsBilledTo, setSameAsBilledTo] = useState<boolean>(true);
  const [shipToName, setShipToName] = useState<string>(customers[0]?.name || '');
  const [shipToGstin, setShipToGstin] = useState<string>(customers[0]?.gstin || '');
  const [shipToContact, setShipToContact] = useState<string>(customers[0]?.phone || '9822000000');
  const [shipToAddress, setShipToAddress] = useState<string>(
    customers[0] ? `${customers[0].address}` : ''
  );

  const [customStateCode, setCustomStateCode] = useState<string>('27');
  const [invDate, setInvDate] = useState<string>('2026-10-09');
  const [challanNo, setChallanNo] = useState<string>('386');
  const [challanDate, setChallanDate] = useState<string>('2026-10-09');
  const [poNumber, setPoNumber] = useState<string>('-');
  const [poDate, setPoDate] = useState<string>('-');
  const [vehicleNo, setVehicleNo] = useState<string>('-');
  const [transportMode, setTransportMode] = useState<string>('Road / Tempo');
  const [selectedHalfGstRate, setSelectedHalfGstRate] = useState<6 | 9 | 12>(9);
  const [initialPaymentStatus, setInitialPaymentStatus] = useState<'UNPAID' | 'PAID' | 'PARTIAL'>('UNPAID');
  const [paymentMode, setPaymentMode] = useState<string>('Bank Transfer (NEFT/RTGS)');
  const [isCustomRoundOff, setIsCustomRoundOff] = useState<boolean>(false);
  const [customRoundOffValue, setCustomRoundOffValue] = useState<string>('0');
  const [invNotes, setInvNotes] = useState<string>('');
  const [editingInvoiceId, setEditingInvoiceId] = useState<string | null>(null);
  const [editingInvoiceNo, setEditingInvoiceNo] = useState<string | null>(null);

  const [lineItems, setLineItems] = useState<InvoiceLineItem[]>([
    {
      id: 'item-init-1',
      serviceId: 'srv-1',
      serviceName: 'MS FRAME FOR POWDER COATING',
      sacCode: '998898',
      partSpecification: 'MS FRAME FOR POWDER COATING',
      unit: 'KGS',
      qty: 1,
      rate: 24,
      amount: 24,
      gstApplicable: true,
      halfGstRate: 9,
    },
  ]);

  // Customer Master Form State (Add + Edit)
  const [editingCustomerId, setEditingCustomerId] = useState<string | null>(null);
  const [newCustName, setNewCustName] = useState('');
  const [newCustGstin, setNewCustGstin] = useState('');
  const [newCustContact, setNewCustContact] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustAddress, setNewCustAddress] = useState('');
  const [newCustCity, setNewCustCity] = useState('Pune - 412105');

  // Coating Service / Product Master State (Add + Edit)
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  const [newServiceName, setNewServiceName] = useState('');
  const [newServiceMarathi, setNewServiceMarathi] = useState('');
  const [newServiceSac, setNewServiceSac] = useState('998898');
  const [newServiceCategory, setNewServiceCategory] =
    useState<CoatingService['category']>('Powder Coating');
  const [newServiceUnit, setNewServiceUnit] = useState<CoatingService['defaultUnit']>('KGS');
  const [newServiceRate, setNewServiceRate] = useState<string>('45');
  const [newServiceSpec, setNewServiceSpec] = useState('');

  // Quick Area / Powder Estimator Calculator on Services Tab
  const [calcLengthFt, setCalcLengthFt] = useState<number>(6);
  const [calcWidthFt, setCalcWidthFt] = useState<number>(4);
  const [calcQtyPanels, setCalcQtyPanels] = useState<number>(20);
  const [calcRateSqFt, setCalcRateSqFt] = useState<number>(28);

  // Synchronize Customer Dropdown Selection
  const handleSelectCustomer = (custId: string) => {
    setSelectedCustomerId(custId);
    const found = customers.find((c) => c.id === custId);
    if (found) {
      setCustomCustomerName(found.name);
      setCustomCustomerGstin(found.gstin);
      setCustomCustomerContact(found.phone);
      setCustomCustomerAddress(found.address);
      setCustomStateCode(found.stateCode || '27');
      if (sameAsBilledTo) {
        setShipToName(found.name);
        setShipToGstin(found.gstin);
        setShipToContact(found.phone);
        setShipToAddress(found.address);
      }
    }
  };

  // Real-Time Dashboard Metrics (Exact match to VD Coating figures initially, dynamic as new bills are saved)
  const metrics = useMemo(() => {
    const validInvoices = invoices.filter((i) => i.status !== 'CANCELLED');
    const totalSales = validInvoices.reduce((acc, inv) => acc + inv.grandTotal, 0);

    // Current Month (October 2026)
    const thisMonthSales = validInvoices
      .filter((inv) => inv.date.startsWith('2026-10'))
      .reduce((acc, inv) => acc + inv.grandTotal, 0);

    // Today's Sales (2026-10-09)
    const todaySales = validInvoices
      .filter((inv) => inv.date === '2026-10-09')
      .reduce((acc, inv) => acc + inv.grandTotal, 0);

    // Pending Payments (Unpaid + Partial balance)
    const pendingInvoices = validInvoices.filter(
      (inv) => inv.status === 'UNPAID' || inv.status === 'PARTIAL'
    );
    const pendingAmount = pendingInvoices.reduce(
      (acc, inv) => acc + Math.max(0, inv.grandTotal - inv.amountPaid),
      0
    );

    const totalGstCollected = validInvoices.reduce((acc, inv) => acc + inv.totalGst, 0);

    return {
      totalSales,
      thisMonthSales,
      todaySales,
      pendingAmount,
      pendingCount: pendingInvoices.length,
      totalGstCollected,
      totalCount: validInvoices.length,
    };
  }, [invoices]);

  // Filtered Invoices
  const filteredInvoices = useMemo(() => {
    return invoices.filter((inv) => {
      const matchesStatus = statusFilter === 'ALL' || inv.status === statusFilter;
      const q = invoiceSearch.trim().toLowerCase();
      if (!q) return matchesStatus;
      return (
        matchesStatus &&
        (inv.invoiceNo.toLowerCase().includes(q) ||
          inv.customerName.toLowerCase().includes(q) ||
          inv.customerGstin.toLowerCase().includes(q) ||
          inv.challanNo.toLowerCase().includes(q))
      );
    });
  }, [invoices, invoiceSearch, statusFilter]);

  // Line Item Handlers in Create Invoice
  const handleAddLineItem = () => {
    const defaultSrv = services[0];
    const newItem: InvoiceLineItem = {
      id: `item-${Date.now()}`,
      serviceId: defaultSrv?.id || 'srv-1',
      serviceName: defaultSrv?.name || 'MS FRAME FOR POWDER COATING',
      sacCode: defaultSrv?.sacCode || '998898',
      partSpecification: defaultSrv?.name || 'MS FRAME FOR POWDER COATING',
      unit: defaultSrv?.defaultUnit || 'KGS',
      qty: 1,
      rate: defaultSrv?.standardRate || 24,
      amount: 1 * (defaultSrv?.standardRate || 24),
      gstApplicable: true,
      halfGstRate: selectedHalfGstRate,
    };
    setLineItems((prev) => [...prev, newItem]);
  };

  const handleUpdateLineItem = (
    id: string,
    field: keyof InvoiceLineItem,
    value: string | number | boolean
  ) => {
    setLineItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const updated = { ...item, [field]: value };

        // If serviceId changed, auto-populate rate, unit, and SAC
        if (field === 'serviceId') {
          if (value === '') {
            updated.serviceId = '';
          } else {
            const srv = services.find((s) => s.id === value);
            if (srv) {
              updated.serviceName = srv.name;
              updated.partSpecification = srv.name;
              updated.sacCode = srv.sacCode || '998898';
              updated.unit = srv.defaultUnit;
              updated.rate = srv.standardRate;
            }
          }
        }

        if (field === 'serviceName' && typeof value === 'string') {
          updated.partSpecification = value;
        }

        const q = Number(updated.qty) || 0;
        const r = Number(updated.rate) || 0;
        updated.amount = Number((q * r).toFixed(2));
        return updated;
      })
    );
  };

  const handleRemoveLineItem = (id: string) => {
    if (lineItems.length <= 1) return;
    setLineItems((prev) => prev.filter((i) => i.id !== id));
  };

  // Draft Invoice Totals Calculation (Supports per-item GST YES/NO & 6%, 9%, 12% Slabs)
  const draftTotals = useMemo(() => {
    const taxable = Number(
      lineItems.reduce((sum, item) => sum + (Number(item.amount) || 0), 0).toFixed(2)
    );
    const totalQty = Number(
      lineItems.reduce((sum, item) => sum + (Number(item.qty) || 0), 0).toFixed(2)
    );
    const isIntraState = customStateCode.trim() === '27';

    let cgstSum = 0;
    let sgstSum = 0;
    let igstSum = 0;

    for (const item of lineItems) {
      const itemTaxable = Number(item.amount) || 0;
      const isGstYes = item.gstApplicable !== false;
      const halfRate = isGstYes ? (item.halfGstRate || selectedHalfGstRate || 9) : 0;
      const halfDec = halfRate / 100;
      const fullDec = (halfRate * 2) / 100;

      if (isIntraState) {
        cgstSum += itemTaxable * halfDec;
        sgstSum += itemTaxable * halfDec;
      } else {
        igstSum += itemTaxable * fullDec;
      }
    }

    const cgst = Number(cgstSum.toFixed(2));
    const sgst = Number(sgstSum.toFixed(2));
    const igst = Number(igstSum.toFixed(2));
    const totalGst = Number((cgst + sgst + igst).toFixed(2));
    const exactGrand = taxable + totalGst;

    let roundOff = 0;
    let grandTotal = 0;
    if (isCustomRoundOff) {
      roundOff = Number((parseFloat(customRoundOffValue) || 0).toFixed(2));
      grandTotal = Number((exactGrand + roundOff).toFixed(2));
    } else {
      const roundedGrand = Math.round(exactGrand);
      roundOff = Number((roundedGrand - exactGrand).toFixed(2));
      grandTotal = roundedGrand;
    }

    return {
      totalQty,
      taxable,
      cgst,
      sgst,
      igst,
      totalGst,
      roundOff,
      grandTotal,
    };
  }, [lineItems, customStateCode, selectedHalfGstRate, isCustomRoundOff, customRoundOffValue]);

  // Save & Generate or Update GST Invoice
  const handleSaveInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    const nextNum = invoices.length + 1;
    const formattedNo = editingInvoiceNo || `2026-27-${String(nextNum).padStart(2, '0')}`;

    const billedName = customCustomerName.trim().toUpperCase() || 'WALK-IN INDUSTRIAL CLIENT';
    const billedGstin = customCustomerGstin.trim().toUpperCase() || '27URP0000000Z0';
    const billedContact = customCustomerContact.trim() || '9822000000';
    const billedAddress =
      customCustomerAddress.trim().toUpperCase() || 'CHAKAN / BHOSARI MIDC INDUSTRIAL AREA, PUNE';

    const firstActiveRate = lineItems[0]?.halfGstRate || selectedHalfGstRate;

    const savedInvoice: Invoice = {
      id: editingInvoiceId || `inv-${Date.now()}`,
      invoiceNo: formattedNo,
      date: invDate || '2026-10-09',
      dueDate: '2026-10-24',
      challanNo: challanNo.trim() || `${380 + nextNum}`,
      challanDate: challanDate || invDate || '2026-10-09',
      poNumber: poNumber.trim() || '-',
      poDate: poDate.trim() || '-',
      vehicleNo: vehicleNo.trim() || '-',
      transportMode: transportMode.trim() || 'Road / Tempo',
      reverseCharge: 'NO',
      customerId: selectedCustomerId || 'cust-custom',
      customerName: billedName,
      customerGstin: billedGstin,
      customerContact: billedContact,
      customerAddress: billedAddress,
      consigneeName: sameAsBilledTo
        ? billedName
        : shipToName.trim().toUpperCase() || billedName,
      consigneeGstin: sameAsBilledTo
        ? billedGstin
        : shipToGstin.trim().toUpperCase() || billedGstin,
      consigneeContact: sameAsBilledTo
        ? billedContact
        : shipToContact.trim() || billedContact,
      consigneeAddress: sameAsBilledTo
        ? billedAddress
        : shipToAddress.trim().toUpperCase() || billedAddress,
      stateCode: customStateCode || '27',
      halfGstRate: firstActiveRate,
      items: lineItems,
      taxableAmount: draftTotals.taxable,
      cgstAmount: draftTotals.cgst,
      sgstAmount: draftTotals.sgst,
      igstAmount: draftTotals.igst,
      totalGst: draftTotals.totalGst,
      roundOff: draftTotals.roundOff,
      grandTotal: draftTotals.grandTotal,
      amountPaid: initialPaymentStatus === 'PAID' ? draftTotals.grandTotal : 0,
      status: initialPaymentStatus,
      paymentMode,
      notes: invNotes || '7-Tank Zinc Phosphating + Micron DFT Tested before dispatch.',
    };

    if (editingInvoiceId) {
      setInvoices((prev) =>
        prev.map((inv) => (inv.id === editingInvoiceId ? savedInvoice : inv))
      );
      setEditingInvoiceId(null);
      setEditingInvoiceNo(null);
      triggerToast(`जीएसटी बिल ${formattedNo} यशस्विरित्या अपडेट झाले आहे! (Invoice Updated)`);
    } else {
      setInvoices((prev) => [savedInvoice, ...prev]);
      triggerToast(`जीएसटी बिल ${formattedNo} यशस्विरित्या सेव्ह झाले आहे! (Tax Invoice Saved)`);
    }

    setSelectedInvoice(savedInvoice);
    setActiveTab('invoices');
  };

  // Toggle Paid / Unpaid Status
  const handleToggleInvoiceStatus = (invoiceId: string) => {
    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id !== invoiceId) return inv;
        const nextStatus: InvoiceStatus = inv.status === 'PAID' ? 'UNPAID' : 'PAID';
        const updated = {
          ...inv,
          status: nextStatus,
          amountPaid: nextStatus === 'PAID' ? inv.grandTotal : 0,
        };
        if (selectedInvoice?.id === invoiceId) {
          setSelectedInvoice(updated);
        }
        return updated;
      })
    );
    triggerToast('Invoice payment status updated.');
  };

  // Duplicate Invoice Handler
  const handleDuplicateInvoice = (inv: Invoice) => {
    const nextNum = invoices.length + 1;
    const formattedNo = `2026-27-${String(nextNum).padStart(2, '0')}`;
    const cloned: Invoice = {
      ...inv,
      id: `inv-${Date.now()}`,
      invoiceNo: formattedNo,
      date: new Date().toISOString().slice(0, 10),
      status: 'UNPAID',
      amountPaid: 0,
    };
    setInvoices((prev) => [cloned, ...prev]);
    setSelectedInvoice(cloned);
    triggerToast(`Duplicate Invoice ${formattedNo} created!`);
  };

  // Edit Invoice Handler (Loads invoice into Create/Edit Invoice builder)
  const handleEditInvoice = (inv: Invoice) => {
    setEditingInvoiceId(inv.id);
    setEditingInvoiceNo(inv.invoiceNo);
    setSelectedCustomerId(inv.customerId || '');
    setCustomCustomerName(inv.customerName);
    setCustomCustomerGstin(inv.customerGstin);
    setCustomCustomerContact(inv.customerContact || '9822000000');
    setCustomCustomerAddress(inv.customerAddress);

    const isSameShip =
      (!inv.consigneeName || inv.consigneeName === inv.customerName) &&
      (!inv.consigneeAddress || inv.consigneeAddress === inv.customerAddress);
    setSameAsBilledTo(isSameShip);
    setShipToName(inv.consigneeName || inv.customerName);
    setShipToGstin(inv.consigneeGstin || inv.customerGstin);
    setShipToContact(inv.consigneeContact || inv.customerContact || '9822000000');
    setShipToAddress(inv.consigneeAddress || inv.customerAddress);

    setCustomStateCode(inv.stateCode || '27');
    setInvDate(inv.date);
    setChallanNo(inv.challanNo);
    setChallanDate(inv.challanDate || inv.date);
    setPoNumber(inv.poNumber);
    setVehicleNo(inv.vehicleNo);
    setTransportMode(inv.transportMode || 'Road / Tempo');
    setSelectedHalfGstRate(inv.halfGstRate || 9);
    setInitialPaymentStatus(inv.status === 'CANCELLED' ? 'UNPAID' : inv.status);
    setPaymentMode(inv.paymentMode || 'Bank Transfer (NEFT/RTGS)');
    setInvNotes(inv.notes || '');
    setLineItems(inv.items);
    setSelectedInvoice(null);
    setActiveTab('create-invoice');
    triggerToast(`Editing Invoice ${inv.invoiceNo} (बिलाची माहिती बदला व सेव्ह करा)`);
  };

  const handleCancelEdit = () => {
    setEditingInvoiceId(null);
    setEditingInvoiceNo('');
    setLineItems([]);
    triggerToast('Edit cancelled. Switched to new invoice mode.');
  };

  // Export CSV for GSTR-1 CA Filing
  const handleExportCSV = () => {
    const headers = [
      'Invoice No',
      'Date',
      'Customer Name',
      'GSTIN',
      'Challan No',
      'Taxable Value (INR)',
      'CGST 9%',
      'SGST 9%',
      'IGST 18%',
      'Grand Total (INR)',
      'Payment Status',
    ];
    const rows = filteredInvoices.map((inv) => [
      inv.invoiceNo,
      inv.date,
      `"${inv.customerName.replace(/"/g, '""')}"`,
      inv.customerGstin,
      inv.challanNo,
      inv.taxableAmount.toFixed(2),
      inv.cgstAmount.toFixed(2),
      inv.sgstAmount.toFixed(2),
      inv.igstAmount.toFixed(2),
      inv.grandTotal.toFixed(2),
      inv.status,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `VD_Coating_GSTR1_Register_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    triggerToast('GSTR-1 Sales Register exported to CSV.');
  };

  // Add or Update Customer Handler
  const handleAddCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName.trim()) return;

    if (editingCustomerId) {
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === editingCustomerId
            ? {
                ...c,
                name: newCustName.trim().toUpperCase(),
                gstin: newCustGstin.trim().toUpperCase() || '27XXXXX0000X1Z0',
                contactPerson: newCustContact.trim() || 'Purchase Manager',
                phone: newCustPhone.trim() || '9822000000',
                address: newCustAddress.trim().toUpperCase() || 'MIDC INDUSTRIAL AREA, KHED',
                city: newCustCity.trim() || 'Pune - 412105',
              }
            : c
        )
      );
      triggerToast(`ग्राहक "${newCustName.trim()}" ची माहिती अपडेट झाली आहे! (Customer Updated)`);
      setEditingCustomerId(null);
    } else {
      const newCustomer: Customer = {
        id: `cust-${Date.now()}`,
        name: newCustName.trim().toUpperCase(),
        gstin: newCustGstin.trim().toUpperCase() || '27XXXXX0000X1Z0',
        contactPerson: newCustContact.trim() || 'Purchase Manager',
        phone: newCustPhone.trim() || '9822000000',
        email: 'accounts@clientpune.in',
        address: newCustAddress.trim().toUpperCase() || 'MIDC INDUSTRIAL AREA, KHED',
        city: newCustCity.trim() || 'Pune - 412105',
        stateCode: '27',
        openingBalance: 0,
      };
      setCustomers((prev) => [newCustomer, ...prev]);
      triggerToast(`Customer "${newCustomer.name}" added to Master Directory.`);
    }

    setNewCustName('');
    setNewCustGstin('');
    setNewCustContact('');
    setNewCustPhone('');
    setNewCustAddress('');
  };

  // Start Editing Customer
  const handleStartEditCustomer = (cust: Customer) => {
    setEditingCustomerId(cust.id);
    setNewCustName(cust.name);
    setNewCustGstin(cust.gstin);
    setNewCustContact(cust.contactPerson);
    setNewCustPhone(cust.phone);
    setNewCustAddress(cust.address);
    setNewCustCity(cust.city);
  };

  // Delete Customer
  const handleDeleteCustomer = (cust: Customer) => {
    setCustomers((prev) => prev.filter((c) => c.id !== cust.id));
    if (editingCustomerId === cust.id) {
      setEditingCustomerId(null);
      setNewCustName('');
      setNewCustGstin('');
      setNewCustContact('');
      setNewCustPhone('');
      setNewCustAddress('');
    }
    triggerToast(`Customer "${cust.name}" deleted from Master.`);
  };

  // Add or Update Product / Service Handler
  const handleAddService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newServiceName.trim()) return;

    if (editingServiceId) {
      setServices((prev) =>
        prev.map((srv) =>
          srv.id === editingServiceId
            ? {
                ...srv,
                name: newServiceName.trim().toUpperCase(),
                marathiName: newServiceMarathi.trim() || srv.marathiName,
                sacCode: newServiceSac.trim() || '998898',
                category: newServiceCategory,
                defaultUnit: newServiceUnit,
                standardRate: parseFloat(newServiceRate) || 45,
                specDetails:
                  newServiceSpec.trim() ||
                  'Industrial Protective Coating as per Standard Micron DFT',
              }
            : srv
        )
      );
      triggerToast(`Product / Service "${newServiceName.trim()}" updated!`);
      setEditingServiceId(null);
    } else {
      const created: CoatingService = {
        id: `srv-${Date.now()}`,
        code: `VD-${services.length + 101}`,
        name: newServiceName.trim().toUpperCase(),
        marathiName: newServiceMarathi.trim() || 'कोटिंग जॉब वर्क सेवा',
        sacCode: newServiceSac.trim() || '998898',
        category: newServiceCategory,
        defaultUnit: newServiceUnit,
        standardRate: parseFloat(newServiceRate) || 45,
        gstPercent: 18,
        specDetails:
          newServiceSpec.trim() || 'Industrial Protective Coating as per Standard Micron DFT',
      };
      setServices((prev) => [...prev, created]);
      triggerToast(`Service "${created.name}" added to Product Master.`);
    }

    setNewServiceName('');
    setNewServiceMarathi('');
    setNewServiceSac('998898');
    setNewServiceSpec('');
  };

  // Start Editing Product / Service
  const handleStartEditService = (srv: CoatingService) => {
    setEditingServiceId(srv.id);
    setNewServiceName(srv.name);
    setNewServiceMarathi(srv.marathiName);
    setNewServiceSac(srv.sacCode);
    setNewServiceCategory(srv.category);
    setNewServiceUnit(srv.defaultUnit);
    setNewServiceRate(String(srv.standardRate));
    setNewServiceSpec(srv.specDetails);
  };

  // Delete Product / Service
  const handleDeleteService = (srv: CoatingService) => {
    setServices((prev) => prev.filter((s) => s.id !== srv.id));
    if (editingServiceId === srv.id) {
      setEditingServiceId(null);
      setNewServiceName('');
      setNewServiceMarathi('');
      setNewServiceSpec('');
    }
    triggerToast(`Product / Service "${srv.name}" deleted from Master.`);
  };

  // Advance Job Order Stage on Shop-Floor Board
  const handleAdvanceJobStage = (jobId: string) => {
    const stages: JobOrder['stage'][] = [
      '7-Tank Pretreatment',
      'Powder / PVD Booth',
      'Curing Oven (200°C)',
      'QC & Ready for Dispatch',
    ];
    setJobOrders((prev) =>
      prev.map((job) => {
        if (job.id !== jobId) return job;
        const idx = stages.indexOf(job.stage);
        const nextStage = stages[(idx + 1) % stages.length];
        return { ...job, stage: nextStage };
      })
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-200 text-slate-900 pb-16 lg:pb-0">
      {/* Top Header Bar: Bold Main Title with Logo */}
      <header className="no-print sticky top-0 z-30 flex items-center justify-between gap-4 px-4 sm:px-6 py-3.5 bg-gray-100 border-b border-gray-300 shadow-2xs">
        <a
          href="#dashboard"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('dashboard');
          }}
          className="flex items-center gap-3 group cursor-pointer"
        >
          <VdLogo size="md" logoUrl={companyInfo.logoUrl} />
          <span className="text-lg sm:text-2xl md:text-3xl font-extrabold tracking-wide text-slate-900 uppercase truncate group-hover:text-blue-700 transition-colors">
            VD COATING SOLUTIONS
          </span>
        </a>

        <div className="flex items-center gap-2.5 shrink-0">
          {!isInstalled && (
            <button
              onClick={async () => {
                if (isInstallable) {
                  await install();
                } else {
                  setShowMobileSyncModal(true);
                }
              }}
              className="px-3.5 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <DownloadCloud className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Install App Icon</span>
              <span className="sm:hidden">App</span>
            </button>
          )}
        </div>
      </header>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="no-print fixed bottom-20 lg:bottom-5 right-5 z-50 bg-white border border-blue-300 text-slate-900 px-4 py-3 rounded-xl shadow-xl flex items-center gap-2.5 text-xs font-semibold">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Workspace Layout: Both Left Sidebar Dashboard + Main Viewport Dashboard have Gray Background */}
      <div className="flex-1 flex flex-col lg:flex-row bg-gray-200">
        {/* Left Sidebar Navigation & Company Profile (Gray Dashboard Background) */}
        <aside className="no-print w-full lg:w-64 bg-gray-200 border-b lg:border-b-0 lg:border-r border-gray-300 p-4 flex flex-col justify-between shrink-0">
          <div className="space-y-4">
            {/* Brand Emblem & Proprietor Block */}
            <div className="flex items-center gap-3 pb-3 border-b border-gray-300">
              <VdLogo size="lg" logoUrl={companyInfo.logoUrl} />
              <div className="min-w-0">
                <div className="font-extrabold text-slate-900 text-sm tracking-wide truncate">
                  {companyInfo.name}
                </div>
                <div className="text-[11px] text-amber-700 font-semibold truncate">
                  Prop: {companyInfo.proprietor}
                </div>
                <div className="text-[11px] text-blue-700 font-medium">
                  GST Tax Invoice
                </div>
              </div>
            </div>

            {/* Verified Company GST & Multi-Device Sync Box */}
            <div className="bg-gray-100 border border-gray-300 p-3.5 rounded-xl text-xs space-y-2 shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase text-slate-600">GSTIN</span>
                <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                  ACTIVE
                </span>
              </div>
              <div className="font-mono font-bold text-slate-900 text-xs tracking-wide">
                {companyInfo.gstin}
              </div>
              <div className="text-[11px] text-slate-600">
                Alandi, Pune (State: 27)
              </div>
              <div className="pt-2 border-t border-gray-300 flex items-center justify-between text-[11px]">
                <span className="text-slate-600">Multi-Device Sync</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold text-[10px]">
                  ● Cloud Live
                </span>
              </div>
            </div>

            {/* Sidebar Navigation Buttons */}
            <nav className="hidden lg:flex flex-col gap-1">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'dashboard'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-800 hover:bg-gray-300/80 hover:text-slate-950'
                }`}
              >
                <LayoutDashboard className="w-4 h-4 shrink-0" />
                <span>Dashboard (डॅशबोर्ड)</span>
              </button>

              <button
                onClick={() => setActiveTab('invoices')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'invoices'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-800 hover:bg-gray-300/80 hover:text-slate-950'
                }`}
              >
                <FileText className="w-4 h-4 shrink-0" />
                <span>Tax Invoices ({invoices.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('create-invoice')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'create-invoice'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-800 hover:bg-gray-300/80 hover:text-slate-950'
                }`}
              >
                <FilePlus2 className="w-4 h-4 shrink-0" />
                <span>{editingInvoiceId ? 'Edit Invoice' : 'Create Invoice'}</span>
              </button>

              <button
                onClick={() => setActiveTab('customers')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'customers'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-800 hover:bg-gray-300/80 hover:text-slate-950'
                }`}
              >
                <Users className="w-4 h-4 shrink-0" />
                <span>Customer Master</span>
              </button>

              <button
                onClick={() => setActiveTab('services')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'services'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-800 hover:bg-gray-300/80 hover:text-slate-950'
                }`}
              >
                <Layers className="w-4 h-4 shrink-0" />
                <span>Product Master</span>
              </button>

              <button
                onClick={() => setActiveTab('reports')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'reports'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-800 hover:bg-gray-300/80 hover:text-slate-950'
                }`}
              >
                <BarChart3 className="w-4 h-4 shrink-0" />
                <span>Reports &amp; GST</span>
              </button>

              <button
                onClick={() => setActiveTab('settings')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'settings'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-800 hover:bg-gray-300/80 hover:text-slate-950'
                }`}
              >
                <Settings className="w-4 h-4 shrink-0" />
                <span>Company Settings</span>
              </button>
            </nav>
          </div>

          {/* Bottom Admin Card + Logout + PC, Tab & Mobile Sync Button */}
          <div className="hidden lg:flex flex-col gap-2.5 pt-4 border-t border-gray-300 mt-6">
            <div className="bg-gray-100 border border-gray-300 p-3 rounded-xl space-y-2.5 shadow-2xs">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-purple-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                  AD
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 truncate">
                    {companyInfo.proprietor} (VD Coating)
                  </div>
                  <div className="text-[10px] font-bold text-purple-600 uppercase">
                    ADMIN (FULL ACCESS)
                  </div>
                </div>
              </div>

              <button
                onClick={() => triggerToast('Logged in as Admin (Full Access).')}
                className="w-full py-2 px-3 rounded-lg bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                लॉगआउट करा (Logout)
              </button>
            </div>

            <button
              onClick={() => setShowMobileSyncModal(true)}
              className="w-full py-2.5 px-3 rounded-xl bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-700 text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Smartphone className="w-4 h-4 text-amber-600 shrink-0" />
              <span>PC, Tab व Mobile Sync</span>
            </button>
          </div>
        </aside>

        {/* Main Content Viewport (Gray Dashboard Background) */}
        <main className="no-print flex-1 p-4 md:p-8 max-w-[1360px] w-full mx-auto space-y-6 bg-gray-200">
          {/* Company Header Banner (VD COATING SOLUTIONS only, no Billing & ERP, no + Tax Invoice button) */}
          <div className="bg-gray-100 border border-gray-300 shadow-2xs p-5 md:p-6 rounded-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center gap-4">
              <VdLogo size="lg" logoUrl={companyInfo.logoUrl} />
              <div>
                <div className="flex flex-wrap items-center gap-2 text-xs text-amber-700 font-semibold mb-1">
                  <span>Protective Coating Experts</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">GSTIN: {companyInfo.gstin}</span>
                  <span aria-hidden="true">·</span>
                  <span>Prop: {companyInfo.proprietor}</span>
                </div>
                <h1 className="text-xl md:text-2xl font-extrabold tracking-tight text-slate-900 uppercase">
                  {companyInfo.name}
                </h1>
                <p className="text-xs text-slate-600 mt-1">
                  {companyInfo.address} · Phone: {companyInfo.phone}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              <button
                onClick={handleExportCSV}
                className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-white hover:bg-gray-50 text-slate-800 border border-gray-300 flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                Export GSTR-1 CSV
              </button>
            </div>
          </div>

          {/* =========================================================
              TAB 1: DASHBOARD (GRAY BACKGROUND)
             ========================================================= */}
          {activeTab === 'dashboard' && (
            <section className="space-y-6 bg-gray-200">
              {/* 4-Column KPI Strip */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-gray-100 border border-gray-300 shadow-2xs p-5 rounded-xl">
                  <div className="text-xs font-semibold text-slate-600 mb-2">
                    Total Sales (एकूण विक्री)
                  </div>
                  <div className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
                    {formatINR(metrics.totalSales)}
                  </div>
                  <div className="text-[11px] text-emerald-700 font-medium mt-1.5">
                    {metrics.totalCount} active GST invoices · Incl. {formatINR(metrics.totalGstCollected)} GST
                  </div>
                </div>

                <div className="bg-gray-100 border border-gray-300 shadow-2xs p-5 rounded-xl">
                  <div className="text-xs font-semibold text-slate-600 mb-2">
                    This Month (चालू महिना)
                  </div>
                  <div className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
                    {formatINR(metrics.thisMonthSales)}
                  </div>
                  <div className="text-[11px] text-blue-700 font-medium mt-1.5">
                    October 2026 Current Billings
                  </div>
                </div>

                <div className="bg-gray-100 border border-gray-300 shadow-2xs p-5 rounded-xl">
                  <div className="text-xs font-semibold text-slate-600 mb-2">
                    Today&apos;s Sales (आजची विक्री)
                  </div>
                  <div className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
                    {formatINR(metrics.todaySales)}
                  </div>
                  <div className="text-[11px] text-amber-700 font-medium mt-1.5">
                    Generated on 09 Oct 2026
                  </div>
                </div>

                <div className="bg-gray-100 border border-gray-300 shadow-2xs p-5 rounded-xl">
                  <div className="text-xs font-semibold text-slate-600 mb-2">
                    Pending Payments (थकीत रक्कम)
                  </div>
                  <div className="text-2xl font-extrabold text-rose-600 font-mono tabular-nums">
                    {formatINR(metrics.pendingAmount)}
                  </div>
                  <div className="text-[11px] text-rose-600 font-medium mt-1.5">
                    Across {metrics.pendingCount} unpaid / partial bills
                  </div>
                </div>
              </div>

              {/* Quick Master Action Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button
                  onClick={() => setActiveTab('create-invoice')}
                  className="text-left bg-gray-100 border border-gray-300 hover:border-blue-500 shadow-2xs p-5 rounded-xl transition-colors flex items-center justify-between group cursor-pointer"
                >
                  <div>
                    <div className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                      New GST Tax Invoice (नवीन बिल)
                    </div>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Auto CGST + SGST calculation, Edit &amp; A4 PDF Download
                    </p>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-blue-600 shrink-0" />
                </button>

                <button
                  onClick={() => setActiveTab('customers')}
                  className="text-left bg-gray-100 border border-gray-300 hover:border-emerald-500 shadow-2xs p-5 rounded-xl transition-colors flex items-center justify-between group cursor-pointer"
                >
                  <div>
                    <div className="text-sm font-bold text-slate-900 group-hover:text-emerald-600 transition-colors">
                      Customer Master (ग्राहक यादी)
                    </div>
                    <p className="text-xs text-slate-600 mt-0.5">
                      {customers.length} registered MIDC clients &amp; GSTIN records
                    </p>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-600 shrink-0" />
                </button>

                <button
                  onClick={() => setActiveTab('services')}
                  className="text-left bg-gray-100 border border-gray-300 hover:border-amber-500 shadow-2xs p-5 rounded-xl transition-colors flex items-center justify-between group cursor-pointer"
                >
                  <div>
                    <div className="text-sm font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                      Active Coating Services (सेवा व दर)
                    </div>
                    <p className="text-xs text-amber-700 mt-0.5">
                      Powder, PVD, Epoxy &amp; 7-Tank Pretreatment (SAC 9988)
                    </p>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-amber-600 shrink-0" />
                </button>
              </div>

              {/* Recent Tax Invoices Table */}
              <div className="bg-gray-100 border border-gray-300 shadow-2xs rounded-xl overflow-hidden">
                <div className="p-4 border-b border-gray-300 flex flex-wrap justify-between items-center gap-3">
                  <div>
                    <h2 className="font-bold text-slate-900 text-sm">
                      Recent Tax Invoices (अलीकडील जीएसटी बिलांची यादी)
                    </h2>
                    <p className="text-xs text-slate-600">
                      Click Edit to modify any invoice or PDF to download the official A4 GST Tax Invoice
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab('invoices')}
                    className="text-xs font-semibold text-blue-700 hover:text-blue-800 cursor-pointer whitespace-nowrap shrink-0"
                  >
                    View All Invoices →
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-gray-200/80 text-slate-700 font-bold border-b border-gray-300">
                      <tr>
                        <th className="py-3 px-4">INVOICE NO</th>
                        <th className="py-3 px-3">DATE</th>
                        <th className="py-3 px-4">CUSTOMER &amp; GSTIN</th>
                        <th className="py-3 px-3 text-right">TAXABLE (₹)</th>
                        <th className="py-3 px-3 text-right">GST (₹)</th>
                        <th className="py-3 px-4 text-right">GRAND TOTAL (₹)</th>
                        <th className="py-3 px-3">PAYMENT STATUS</th>
                        <th className="py-3 px-4 text-right">EDIT / DOWNLOAD</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-300 text-slate-800">
                      {invoices.slice(0, 5).map((inv) => (
                        <tr
                          key={inv.id}
                          className="hover:bg-gray-200/60 transition-colors"
                        >
                          <td className="py-3 px-4 font-mono font-bold text-blue-700">
                            <button
                              type="button"
                              onClick={() => setSelectedInvoice(inv)}
                              className="hover:underline text-left cursor-pointer"
                              title="View Full Tax Invoice with Logo"
                            >
                              {inv.invoiceNo}
                            </button>
                          </td>
                          <td className="py-3 px-3 font-mono text-slate-700">{inv.date}</td>
                          <td className="py-3 px-4">
                            <div className="font-bold text-slate-900">{inv.customerName}</div>
                            <div className="text-[11px] font-mono text-slate-600">
                              {inv.customerGstin} · Challan {inv.challanNo}
                            </div>
                          </td>
                          <td className="py-3 px-3 text-right font-mono tabular-nums font-medium">
                            {formatINR(inv.taxableAmount)}
                          </td>
                          <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                            {formatINR(inv.totalGst)}
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums font-extrabold text-emerald-700">
                            {formatINR(inv.grandTotal)}
                          </td>
                          <td className="py-3 px-3 font-mono text-[11px]">
                            {inv.status === 'PAID' && (
                              <span className="text-emerald-700 font-bold">
                                PAID · Settled
                              </span>
                            )}
                            {inv.status === 'UNPAID' && (
                              <span className="text-rose-600 font-bold">
                                UNPAID · Due
                              </span>
                            )}
                            {inv.status === 'PARTIAL' && (
                              <span className="text-amber-700 font-bold">
                                PARTIAL · Bal {formatINR(inv.grandTotal - inv.amountPaid)}
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => setSelectedInvoice(inv)}
                                className="px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold inline-flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                                title="View Invoice (बिल पहा)"
                              >
                                <FileText className="w-3 h-3" />
                                View
                              </button>
                              <button
                                onClick={() => handleEditInvoice(inv)}
                                className="px-2.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold inline-flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                                title="Edit Invoice (बिल एडिट करा)"
                              >
                                <Pencil className="w-3 h-3" />
                                Edit
                              </button>
                              <button
                                onClick={async () => {
                                  await downloadInvoicePdf(inv, companyInfo);
                                  triggerToast(`Invoice ${inv.invoiceNo} PDF downloaded!`);
                                }}
                                className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold inline-flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                                title="Download PDF"
                              >
                                <Download className="w-3 h-3" />
                                PDF
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Active Coating Shop-Floor Job Cards */}
              <div className="bg-gray-100 border border-gray-300 shadow-2xs rounded-xl overflow-hidden">
                <div className="p-4 border-b border-gray-300 flex flex-wrap justify-between items-center gap-2">
                  <div className="flex items-center gap-2">
                    <Factory className="w-4 h-4 text-amber-600" />
                    <h3 className="font-bold text-slate-900 text-sm">
                      Live Shop-Floor Coating Batch Tracker (कारखाना जॉब कार्ड स्थिती)
                    </h3>
                  </div>
                  <span className="text-xs text-slate-600">
                    Click stage button to update batch progress from 7-Tank Pretreatment to Dispatch
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-gray-300">
                  {jobOrders.map((job) => (
                    <div key={job.id} className="p-4 space-y-2">
                      <div className="flex items-center justify-between text-xs text-slate-600 font-mono">
                        <span className="text-amber-700 font-bold">{job.jobCardNo}</span>
                        <span>{job.challanNo}</span>
                      </div>
                      <div className="font-bold text-slate-900 text-sm">{job.customerName}</div>
                      <div className="text-xs text-slate-700">{job.partName}</div>
                      <div className="text-xs text-slate-600">
                        {job.coatingType} · <span className="text-slate-800 font-medium">{job.shadeCode}</span> ·{' '}
                        <span className="font-mono font-bold text-slate-900">{job.weightOrQty}</span>
                      </div>
                      <div className="pt-2 flex items-center justify-between">
                        <span className="text-[11px] text-slate-600">Current Stage:</span>
                        <button
                          onClick={() => handleAdvanceJobStage(job.id)}
                          className="px-2.5 py-1 rounded-lg bg-blue-50 border border-blue-200 hover:bg-blue-100 text-blue-700 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                        >
                          {job.stage} ↻
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          )}

          {/* =========================================================
              TAB 2: CREATE / EDIT INVOICE (जीएसटी बिल तयार किंवा एडिट करा)
             ========================================================= */}
          {activeTab === 'create-invoice' && (
            <section className="space-y-6">
              <form
                onSubmit={handleSaveInvoice}
                className="bg-gray-100 border border-gray-300 shadow-2xs p-6 rounded-xl space-y-6"
              >
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-300 pb-4">
                  <div className="flex items-center gap-3.5">
                    <VdLogo size="lg" logoUrl={companyInfo.logoUrl} />
                    <div>
                      <h2 className="text-lg font-extrabold text-slate-900">
                        {editingInvoiceId
                          ? `जीएसटी बिल एडिट करा (Edit GST Tax Invoice — ${editingInvoiceNo})`
                          : 'नवीन जीएसटी बिल तयार करा (New GST Tax Invoice — Rule 46 Format)'}
                      </h2>
                      <p className="text-xs text-slate-600">
                        {editingInvoiceId ? (
                          <>
                            Editing Invoice No:{' '}
                            <span className="font-mono text-amber-700 font-bold">
                              {editingInvoiceNo}
                            </span>
                          </>
                        ) : (
                          <>
                            Next Auto-Number:{' '}
                            <span className="font-mono text-blue-600 font-bold">
                              2026-27-{String(invoices.length + 1).padStart(2, '0')}
                            </span>
                          </>
                        )}{' '}
                        · HSN/SAC: 998898
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {editingInvoiceId && (
                      <button
                        type="button"
                        onClick={handleCancelEdit}
                        className="px-3 py-2 rounded-lg bg-amber-100 hover:bg-amber-200 border border-amber-300 text-amber-900 text-xs font-bold cursor-pointer transition-colors"
                      >
                        ✕ Cancel Edit (रद्द करा)
                      </button>
                    )}
                    <span className="text-xs font-semibold text-slate-700">Select Saved Client:</span>
                    <select
                      value={selectedCustomerId}
                      onChange={(e) => handleSelectCustomer(e.target.value)}
                      className="bg-white border border-gray-300 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900 focus:border-blue-600 outline-none"
                    >
                      {customers.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name} ({c.gstin})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Bill To & Ship To Split with "Same as Bill To" Tick Mark */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  {/* LEFT BOX: BILL TO (DETAILS OF RECEIVER) */}
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3.5">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
                      <span className="text-xs font-extrabold uppercase tracking-wider text-blue-700">
                        1. BILL TO — Details of Receiver (बिल कोणाच्या नावे)
                      </span>
                      <span className="text-[11px] font-mono font-semibold text-slate-600">
                        State Code: {customStateCode}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="sm:col-span-2">
                        <label className="block text-xs text-slate-700 font-semibold mb-1">
                          Customer / Company Name (ग्राहकाचे नाव) *
                        </label>
                        <input
                          type="text"
                          required
                          value={customCustomerName}
                          onChange={(e) => setCustomCustomerName(e.target.value)}
                          placeholder="e.g. MECON SYSTEMS"
                          className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-900 focus:border-blue-600 outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs text-slate-700 font-semibold mb-1">
                          Customer GSTIN (जीएसटी क्र.) *
                        </label>
                        <input
                          type="text"
                          required
                          value={customCustomerGstin}
                          onChange={(e) => setCustomCustomerGstin(e.target.value.toUpperCase())}
                          placeholder="27AGJPA8641A1ZR"
                          className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-semibold text-slate-900 focus:border-blue-600 outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs text-slate-700 font-semibold mb-1">
                          Contact No. (मोबाईल क्र.)
                        </label>
                        <input
                          type="text"
                          value={customCustomerContact}
                          onChange={(e) => setCustomCustomerContact(e.target.value)}
                          placeholder="9822000000"
                          className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-semibold text-slate-900 focus:border-blue-600 outline-none"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs text-slate-700 font-semibold mb-1">
                          Bill To Address (बिलिंग पत्ता - Gat No / MIDC / Pune) *
                        </label>
                        <input
                          type="text"
                          required
                          value={customCustomerAddress}
                          onChange={(e) => setCustomCustomerAddress(e.target.value)}
                          placeholder="GAT NO 62/3/A AT-POST CHIMBLI TAL-KHED DIST PUNE"
                          className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-900 focus:border-blue-600 outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* RIGHT BOX: SHIP TO (DETAILS OF CONSIGNEE) WITH TICK MARK */}
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3.5">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-2.5">
                      <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-700">
                        2. SHIP TO — Details of Consignee (डिलिव्हरी पत्ता)
                      </span>

                      {/* Checkbox Tick Mark: Same as Bill To */}
                      <label className="inline-flex items-center gap-2 cursor-pointer select-none bg-white border border-slate-300 hover:border-blue-500 px-3 py-1 rounded-lg transition-colors">
                        <input
                          type="checkbox"
                          checked={sameAsBilledTo}
                          onChange={(e) => {
                            const checked = e.target.checked;
                            setSameAsBilledTo(checked);
                            if (!checked) {
                              setShipToName(customCustomerName);
                              setShipToGstin(customCustomerGstin);
                              setShipToContact(customCustomerContact);
                              setShipToAddress('');
                            }
                          }}
                          className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
                        />
                        <span className="text-xs font-bold text-slate-800">
                          Same as Bill To (पत्ता सेम आहे)
                        </span>
                      </label>
                    </div>

                    {sameAsBilledTo ? (
                      <div className="p-3.5 rounded-lg bg-white border border-slate-200 space-y-1.5 text-xs">
                        <div className="flex items-center gap-2 text-emerald-700 font-bold">
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                          <span>
                            Ship To details automatically copied from Bill To (टिक काढल्यास वेगळा पत्ता टाकता येईल)
                          </span>
                        </div>
                        <div className="pt-1 text-slate-900 font-bold uppercase">
                          {customCustomerName || '—'}
                        </div>
                        <div className="text-slate-600 uppercase">
                          {customCustomerAddress || '—'}
                        </div>
                        <div className="text-slate-500 font-mono text-[11px] pt-0.5">
                          GSTIN: {customCustomerGstin || '—'} · Contact: {customCustomerContact || '—'}
                        </div>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="sm:col-span-2">
                          <label className="block text-xs text-slate-700 font-semibold mb-1">
                            Consignee / Ship To Party Name (डिलिव्हरी पार्टीचे नाव) *
                          </label>
                          <input
                            type="text"
                            required
                            value={shipToName}
                            onChange={(e) => setShipToName(e.target.value)}
                            placeholder="Enter Consignee Company Name"
                            className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-900 focus:border-blue-600 outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-xs text-slate-700 font-semibold mb-1">
                            Ship To GSTIN
                          </label>
                          <input
                            type="text"
                            value={shipToGstin}
                            onChange={(e) => setShipToGstin(e.target.value.toUpperCase())}
                            placeholder="27XXXXX0000X1Z0"
                            className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-semibold text-slate-900 focus:border-blue-600 outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-xs text-slate-700 font-semibold mb-1">
                            Ship To Contact No.
                          </label>
                          <input
                            type="text"
                            value={shipToContact}
                            onChange={(e) => setShipToContact(e.target.value)}
                            placeholder="9822000000"
                            className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-semibold text-slate-900 focus:border-blue-600 outline-none"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-xs text-slate-700 font-semibold mb-1">
                            Ship To / Delivery Address (वेगळा डिलिव्हरी पत्ता टाका) *
                          </label>
                          <input
                            type="text"
                            required
                            value={shipToAddress}
                            onChange={(e) => setShipToAddress(e.target.value)}
                            placeholder="Enter Plant 2 / Site Delivery Address"
                            className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-900 focus:border-blue-600 outline-none"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Invoice Date, Challan, PO & Transport Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3.5">
                  <div>
                    <label className="block text-xs text-slate-700 font-semibold mb-1">
                      Invoice Date (बिलाची तारीख) *
                    </label>
                    <input
                      type="date"
                      required
                      value={invDate}
                      onChange={(e) => setInvDate(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-semibold text-slate-900 focus:border-blue-600 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-700 font-semibold mb-1">
                      Challan No. &amp; Date (चलन क्र.)
                    </label>
                    <div className="grid grid-cols-2 gap-1.5">
                      <input
                        type="text"
                        value={challanNo}
                        onChange={(e) => setChallanNo(e.target.value)}
                        placeholder="385"
                        className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-semibold text-slate-900 focus:border-blue-600 outline-none"
                      />
                      <input
                        type="date"
                        value={challanDate}
                        onChange={(e) => setChallanDate(e.target.value)}
                        className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs font-mono font-semibold text-slate-900 focus:border-blue-600 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-700 font-semibold mb-1">
                      PO Number (खरेदी आदेश क्र.)
                    </label>
                    <input
                      type="text"
                      value={poNumber}
                      onChange={(e) => setPoNumber(e.target.value)}
                      placeholder="-"
                      className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-semibold text-slate-900 focus:border-blue-600 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-700 font-semibold mb-1">
                      Vehicle No. (वाहन क्र.)
                    </label>
                    <input
                      type="text"
                      value={vehicleNo}
                      onChange={(e) => setVehicleNo(e.target.value.toUpperCase())}
                      placeholder="MH-14-JL-4921 or -"
                      className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-semibold text-slate-900 focus:border-blue-600 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-700 font-semibold mb-1">
                      Transport Mode
                    </label>
                    <input
                      type="text"
                      value={transportMode}
                      onChange={(e) => setTransportMode(e.target.value)}
                      placeholder="Road / Tempo"
                      className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-900 focus:border-blue-600 outline-none"
                    />
                  </div>
                </div>

                {/* =========================================================
                    JOB WORK PARTICULARS TABLE (EXACT MATCH TO UPLOADED SCREENSHOT)
                   ========================================================= */}
                <div className="space-y-3 pt-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wide">
                        Job Work Particulars &amp; Product Details (जॉब वर्क व मालाचा तपशील)
                      </h3>
                      <select
                        value={customStateCode}
                        onChange={(e) => setCustomStateCode(e.target.value)}
                        className="bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1 text-[11px] font-bold text-blue-700 outline-none"
                      >
                        <option value="27">Maharashtra State: 27 (CGST + SGST)</option>
                        <option value="24">Inter-State Supply (IGST)</option>
                      </select>
                    </div>
                    <button
                      type="button"
                      onClick={handleAddLineItem}
                      className="px-3.5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      + Add Item (नवीन आयटम जोडा)
                    </button>
                  </div>

                  {/* White High-Clarity Table Card Matching Screenshot */}
                  <div className="bg-white text-slate-900 rounded-2xl border border-slate-200 shadow-lg overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse min-w-[920px]">
                        <thead>
                          <tr className="bg-[#F8FAFC] border-b border-slate-200 text-[11px] font-extrabold text-slate-600 uppercase tracking-wider">
                            <th className="py-3.5 px-4 w-10 text-center">#</th>
                            <th className="py-3.5 px-3 min-w-[260px]">DESCRIPTION / PRODUCT</th>
                            <th className="py-3.5 px-3 w-28 text-center">HSN/SAC</th>
                            <th className="py-3.5 px-3 w-28 text-center">QTY (नग/प्रमाण)</th>
                            <th className="py-3.5 px-3 w-28 text-center">UNIT (एकक)</th>
                            <th className="py-3.5 px-3 w-36 text-right">RATE (दर ₹)</th>
                            <th className="py-3 px-4 w-36 text-right leading-tight">
                              <div>TAXABLE (करपात्र ₹)</div>
                              <div className="text-[9.5px] font-semibold text-slate-400">
                                GST: YES / NO
                              </div>
                            </th>
                            <th className="py-3.5 px-4 w-36 text-right">GST SLAB</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {lineItems.map((item, index) => {
                            const isGstYes = item.gstApplicable !== false;
                            const itemHalfRate = item.halfGstRate || selectedHalfGstRate || 9;

                            return (
                              <tr
                                key={item.id}
                                className="hover:bg-slate-50/70 transition-colors align-middle"
                              >
                                {/* 1. Row Index (#) */}
                                <td className="py-4 px-4 text-center font-bold text-xs text-slate-500">
                                  {index + 1}
                                </td>

                                {/* 2. DESCRIPTION / PRODUCT (Dropdown + Clear 'X' on Top, Editable Bold Input Below) */}
                                <td className="py-3.5 px-3 space-y-1.5">
                                  <div className="flex items-center gap-1.5">
                                    <select
                                      value={item.serviceId}
                                      onChange={(e) =>
                                        handleUpdateLineItem(item.id, 'serviceId', e.target.value)
                                      }
                                      className="flex-1 bg-slate-50 border border-slate-300 hover:border-slate-400 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-700 outline-none focus:border-blue-600"
                                    >
                                      <option value="">-- Select Product from Master --</option>
                                      {services.map((srv) => (
                                        <option key={srv.id} value={srv.id}>
                                          {srv.name}
                                        </option>
                                      ))}
                                    </select>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        handleUpdateLineItem(item.id, 'serviceId', '');
                                        handleUpdateLineItem(item.id, 'serviceName', '');
                                      }}
                                      title="Clear product selection"
                                      className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-500 hover:text-slate-800 text-xs font-bold flex items-center justify-center shrink-0 cursor-pointer"
                                    >
                                      ✕
                                    </button>
                                  </div>

                                  <input
                                    type="text"
                                    required
                                    value={item.serviceName}
                                    onChange={(e) =>
                                      handleUpdateLineItem(
                                        item.id,
                                        'serviceName',
                                        e.target.value.toUpperCase()
                                      )
                                    }
                                    placeholder="Type Product / Job Work Description..."
                                    className="w-full bg-white border border-slate-300 focus:border-blue-600 rounded-lg px-3 py-2 text-xs font-extrabold text-slate-900 uppercase outline-none shadow-2xs"
                                  />
                                </td>

                                {/* 3. HSN/SAC Code Input */}
                                <td className="py-3.5 px-3 text-center">
                                  <input
                                    type="text"
                                    value={item.sacCode}
                                    onChange={(e) =>
                                      handleUpdateLineItem(item.id, 'sacCode', e.target.value)
                                    }
                                    placeholder="998898"
                                    className="w-24 mx-auto bg-white border border-slate-300 focus:border-blue-600 rounded-lg px-2.5 py-2 text-xs font-semibold text-center text-slate-800 outline-none"
                                  />
                                </td>

                                {/* 4. QTY (नग/प्रमाण) */}
                                <td className="py-3.5 px-3 text-center">
                                  <input
                                    type="number"
                                    min="0.01"
                                    step="any"
                                    required
                                    value={item.qty}
                                    onChange={(e) =>
                                      handleUpdateLineItem(
                                        item.id,
                                        'qty',
                                        parseFloat(e.target.value) || 0
                                      )
                                    }
                                    className="w-24 mx-auto bg-white border border-blue-400 focus:border-blue-600 rounded-xl px-3 py-2.5 text-sm font-extrabold text-center text-slate-900 outline-none"
                                  />
                                </td>

                                {/* 5. UNIT (एकक) */}
                                <td className="py-3.5 px-3 text-center">
                                  <select
                                    value={item.unit}
                                    onChange={(e) =>
                                      handleUpdateLineItem(item.id, 'unit', e.target.value)
                                    }
                                    className="w-24 mx-auto bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-2.5 py-2.5 text-xs font-extrabold text-slate-900 outline-none"
                                  >
                                    <option value="KGS">KGS</option>
                                    <option value="SQ.FT">SQ.FT</option>
                                    <option value="NOS">NOS</option>
                                    <option value="LOT">LOT</option>
                                    <option value="MTR">MTR</option>
                                    <option value="SET">SET</option>
                                  </select>
                                </td>

                                {/* 6. RATE (दर ₹) */}
                                <td className="py-3.5 px-3 text-right">
                                  <input
                                    type="number"
                                    min="0"
                                    step="any"
                                    required
                                    value={item.rate}
                                    onChange={(e) =>
                                      handleUpdateLineItem(
                                        item.id,
                                        'rate',
                                        parseFloat(e.target.value) || 0
                                      )
                                    }
                                    className="w-32 ml-auto bg-white border-2 border-emerald-500 focus:border-emerald-600 rounded-xl px-3 py-2.5 text-sm font-extrabold text-right text-slate-900 outline-none"
                                  />
                                </td>

                                {/* 7. TAXABLE (करपात्र ₹) + GST: YES / NO Toggle */}
                                <td className="py-3.5 px-4 text-right">
                                  <div className="text-sm font-extrabold font-mono text-slate-900">
                                    ₹{Number(item.amount || 0).toFixed(2)}
                                  </div>
                                  <div className="inline-flex items-center rounded-md bg-slate-100 p-0.5 border border-slate-200 mt-1">
                                    <button
                                      type="button"
                                      onClick={() =>
                                        handleUpdateLineItem(item.id, 'gstApplicable', true)
                                      }
                                      className={`px-2 py-0.5 rounded text-[9.5px] font-extrabold transition-colors cursor-pointer ${
                                        isGstYes
                                          ? 'bg-blue-600 text-white shadow-2xs'
                                          : 'text-slate-500 hover:text-slate-800'
                                      }`}
                                    >
                                      GST: YES
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        handleUpdateLineItem(item.id, 'gstApplicable', false)
                                      }
                                      className={`px-2 py-0.5 rounded text-[9.5px] font-extrabold transition-colors cursor-pointer ${
                                        !isGstYes
                                          ? 'bg-slate-700 text-white shadow-2xs'
                                          : 'text-slate-500 hover:text-slate-800'
                                      }`}
                                    >
                                      NO
                                    </button>
                                  </div>
                                </td>

                                {/* 8. Per-Item GST Rate Selector (6%, 9%, 12%) + Delete Row */}
                                <td className="py-3.5 px-4 text-right">
                                  <div className="flex flex-col items-end gap-1.5">
                                    <div className="inline-flex items-center gap-1">
                                      {([6, 9, 12] as const).map((rateOpt) => (
                                        <button
                                          key={rateOpt}
                                          type="button"
                                          disabled={!isGstYes}
                                          onClick={() => {
                                            handleUpdateLineItem(item.id, 'halfGstRate', rateOpt);
                                            setSelectedHalfGstRate(rateOpt);
                                          }}
                                          className={`px-2 py-0.5 rounded text-[10px] font-extrabold transition-colors cursor-pointer ${
                                            isGstYes && itemHalfRate === rateOpt
                                              ? 'bg-blue-600 text-white'
                                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200 disabled:opacity-40'
                                          }`}
                                        >
                                          {rateOpt}%
                                        </button>
                                      ))}
                                    </div>

                                    <div className="flex items-center gap-1.5">
                                      <select
                                        disabled={!isGstYes}
                                        value={itemHalfRate}
                                        onChange={(e) => {
                                          const r = Number(e.target.value) as 6 | 9 | 12;
                                          handleUpdateLineItem(item.id, 'halfGstRate', r);
                                          setSelectedHalfGstRate(r);
                                        }}
                                        className="bg-white border border-slate-300 rounded-lg px-2 py-1 text-[11px] font-bold text-slate-800 outline-none disabled:opacity-50"
                                      >
                                        <option value={6}>6% (Total 12%)</option>
                                        <option value={9}>9% (Total 18%)</option>
                                        <option value={12}>12% (Total 24%)</option>
                                      </select>

                                      {lineItems.length > 1 && (
                                        <button
                                          type="button"
                                          onClick={() => handleRemoveLineItem(item.id)}
                                          className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 border border-transparent hover:border-rose-200 transition-colors cursor-pointer"
                                          title="Remove row"
                                        >
                                          <Trash2 className="w-4 h-4" />
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                {/* =========================================================
                    BOTTOM SPLIT: PAYMENT & ADDITIONAL INFORMATION + FINANCIAL SUMMARY
                    (EXACT MATCH TO UPLOADED SCREENSHOT)
                   ========================================================= */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
                  {/* LEFT CARD (7 COLS): PAYMENT & ADDITIONAL INFORMATION */}
                  <div className="lg:col-span-7 bg-white text-slate-900 rounded-2xl border border-slate-200 p-6 shadow-lg flex flex-col justify-between space-y-5">
                    <div className="space-y-4">
                      <h3 className="text-sm font-extrabold uppercase tracking-wider text-slate-900">
                        PAYMENT &amp; ADDITIONAL INFORMATION
                      </h3>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                            Payment Status
                          </label>
                          <select
                            value={initialPaymentStatus}
                            onChange={(e) =>
                              setInitialPaymentStatus(
                                e.target.value as 'UNPAID' | 'PAID' | 'PARTIAL'
                              )
                            }
                            className="w-full bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3.5 py-2.5 text-sm font-bold text-slate-900 outline-none"
                          >
                            <option value="UNPAID">Pending</option>
                            <option value="PAID">Paid</option>
                            <option value="PARTIAL">Partial</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                            Payment Mode
                          </label>
                          <select
                            value={paymentMode}
                            onChange={(e) => setPaymentMode(e.target.value)}
                            className="w-full bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3.5 py-2.5 text-sm font-bold text-slate-900 outline-none"
                          >
                            <option value="Bank Transfer (NEFT/RTGS)">
                              Bank Transfer (NEFT/RTGS)
                            </option>
                            <option value="Cash">Cash (रोख)</option>
                            <option value="UPI / GPay / PhonePe">UPI / GPay / PhonePe</option>
                            <option value="Cheque">Cheque (चेक)</option>
                            <option value="Credit">Credit (उधारी)</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                          Internal Remarks / Job Work Notes
                        </label>
                        <textarea
                          rows={3}
                          value={invNotes}
                          onChange={(e) => setInvNotes(e.target.value)}
                          placeholder="Job work instructions, batch number, shade code details, etc."
                          className="w-full bg-white border border-slate-300 focus:border-blue-600 rounded-xl p-3 text-xs text-slate-800 outline-none resize-y"
                        />
                      </div>
                    </div>

                    {/* Auto Generated Amount in Words Box */}
                    <div className="bg-blue-50/70 border border-blue-200/80 rounded-xl p-4">
                      <span className="block text-[10px] font-extrabold uppercase tracking-wider text-blue-700">
                        AMOUNT IN WORDS (AUTO GENERATED):
                      </span>
                      <span className="block text-xs font-extrabold text-slate-900 uppercase mt-1">
                        {numberToIndianRupeesWords(draftTotals.grandTotal).toUpperCase()}
                      </span>
                    </div>
                  </div>

                  {/* RIGHT CARD (5 COLS): FINANCIAL SUMMARY */}
                  <div className="lg:col-span-5 bg-white text-slate-900 rounded-2xl border border-slate-200 p-6 shadow-lg flex flex-col justify-between space-y-5">
                    <div className="space-y-3.5">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                        <h3 className="text-sm font-extrabold uppercase tracking-wider text-slate-900">
                          FINANCIAL SUMMARY
                        </h3>
                        <span className="text-xs font-bold font-mono text-slate-500 uppercase">
                          QTY: {draftTotals.totalQty}
                        </span>
                      </div>

                      <div className="space-y-3 text-xs">
                        <div className="flex items-center justify-between text-slate-600">
                          <span className="font-medium">Subtotal (Taxable Amount):</span>
                          <span className="font-mono font-bold text-slate-900">
                            ₹{draftTotals.taxable.toFixed(2)}
                          </span>
                        </div>

                        {customStateCode === '27' ? (
                          <>
                            <div className="flex items-center justify-between text-slate-600">
                              <span className="font-medium">Central GST (CGST):</span>
                              <span className="font-mono font-bold text-slate-900">
                                ₹{draftTotals.cgst.toFixed(2)}
                              </span>
                            </div>
                            <div className="flex items-center justify-between text-slate-600">
                              <span className="font-medium">State GST (SGST):</span>
                              <span className="font-mono font-bold text-slate-900">
                                ₹{draftTotals.sgst.toFixed(2)}
                              </span>
                            </div>
                          </>
                        ) : (
                          <div className="flex items-center justify-between text-slate-600">
                            <span className="font-medium">Integrated GST (IGST):</span>
                            <span className="font-mono font-bold text-slate-900">
                              ₹{draftTotals.igst.toFixed(2)}
                            </span>
                          </div>
                        )}

                        <div className="flex items-center justify-between pt-1">
                          <span className="font-bold text-slate-700">Total GST (Tax):</span>
                          <span className="font-mono font-extrabold text-blue-600">
                            ₹{draftTotals.totalGst.toFixed(2)}
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-slate-600 pt-1">
                          <div className="flex items-center gap-1.5">
                            <span className="font-medium">Round Off:</span>
                            <button
                              type="button"
                              onClick={() => {
                                setIsCustomRoundOff(!isCustomRoundOff);
                                setCustomRoundOffValue(String(draftTotals.roundOff));
                              }}
                              className="text-[11px] font-semibold text-blue-600 hover:underline cursor-pointer"
                            >
                              {isCustomRoundOff ? '(Auto)' : '(Custom)'}
                            </button>
                          </div>

                          {isCustomRoundOff ? (
                            <input
                              type="number"
                              step="0.01"
                              value={customRoundOffValue}
                              onChange={(e) => setCustomRoundOffValue(e.target.value)}
                              className="w-20 bg-slate-50 border border-slate-300 rounded px-2 py-1 text-right font-mono font-bold text-slate-900 outline-none"
                            />
                          ) : (
                            <span className="font-mono font-bold text-slate-900">
                              {draftTotals.roundOff > 0
                                ? `+${draftTotals.roundOff.toFixed(2)}`
                                : draftTotals.roundOff.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4 pt-3 border-t-2 border-slate-200">
                      {/* Clean Light Blue Grand Total Box */}
                      <div className="bg-blue-50 border border-blue-200 text-slate-900 p-4 rounded-xl flex items-center justify-between shadow-2xs">
                        <div>
                          <div className="text-[11px] font-extrabold text-blue-800 uppercase tracking-wide">
                            GRAND TOTAL (INR)
                          </div>
                          <div className="text-[10px] text-slate-500">
                            Inclusive of all taxes
                          </div>
                        </div>
                        <div className="text-2xl font-extrabold font-mono text-blue-700">
                          ₹{draftTotals.grandTotal.toFixed(2)}
                        </div>
                      </div>

                      {/* Primary Save / Update Invoice Button (No Print Option) */}
                      <button
                        type="submit"
                        className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3.5 px-5 rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg transition-colors cursor-pointer"
                      >
                        <Check className="w-4 h-4" />
                        {editingInvoiceId
                          ? `Update Invoice (${editingInvoiceNo} सेव्ह करा)`
                          : 'Save GST Invoice (बिल सेव्ह करा)'}
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </section>
          )}

          {/* =========================================================
              TAB 3: ALL INVOICES REGISTER
             ========================================================= */}
          {activeTab === 'invoices' && (
            <section className="space-y-4">
              {/* Filter & Search Bar */}
              <div className="bg-gray-100 border border-gray-300 shadow-2xs p-4 rounded-xl flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={invoiceSearch}
                    onChange={(e) => setInvoiceSearch(e.target.value)}
                    placeholder="Search by Invoice No, Customer Name, GSTIN, or Challan..."
                    className="w-full bg-white border border-gray-300 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-900 focus:border-blue-600 outline-none"
                  />
                </div>

                {/* Interactive Segmented Status Filter */}
                <div className="flex items-center gap-1 p-1 bg-gray-200 rounded-lg border border-gray-300">
                  {(['ALL', 'PAID', 'UNPAID', 'PARTIAL'] as const).map((st) => (
                    <button
                      key={st}
                      onClick={() => setStatusFilter(st)}
                      className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        statusFilter === st
                          ? 'bg-blue-600 text-white shadow-2xs'
                          : 'text-slate-700 hover:text-slate-900'
                      }`}
                    >
                      {st === 'ALL' ? 'All Bills' : st}
                    </button>
                  ))}
                </div>
              </div>

              {/* Full Invoices Register Table */}
              <div className="bg-gray-100 border border-gray-300 shadow-2xs rounded-xl overflow-hidden">
                <div className="p-4 border-b border-gray-300 flex justify-between items-center">
                  <h2 className="font-bold text-slate-900 text-sm">
                    All GST Tax Invoices (सर्व तयार केलेल्या बिलांची यादी — {filteredInvoices.length})
                  </h2>
                  <button
                    onClick={handleExportCSV}
                    className="text-xs text-blue-700 hover:text-blue-800 font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download CSV
                  </button>
                </div>

                {filteredInvoices.length === 0 ? (
                  <div className="p-12 text-center space-y-3">
                    <p className="text-sm text-slate-600">
                      No GST invoices match your current filter criteria.
                    </p>
                    <button
                      onClick={() => {
                        setInvoiceSearch('');
                        setStatusFilter('ALL');
                      }}
                      className="px-4 py-2 rounded-lg text-xs font-semibold bg-blue-600 text-white cursor-pointer"
                    >
                      Reset Filters
                    </button>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-gray-200/80 text-slate-700 font-bold border-b border-gray-300">
                        <tr>
                          <th className="py-3 px-4">INVOICE NO</th>
                          <th className="py-3 px-3">DATE</th>
                          <th className="py-3 px-3">CHALLAN</th>
                          <th className="py-3 px-4">CUSTOMER &amp; GSTIN</th>
                          <th className="py-3 px-3 text-right">TAXABLE (₹)</th>
                          <th className="py-3 px-3 text-right">GST (₹)</th>
                          <th className="py-3 px-4 text-right">GRAND TOTAL (₹)</th>
                          <th className="py-3 px-3">STATUS</th>
                          <th className="py-3 px-4 text-right">EDIT / DOWNLOAD</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-300 text-slate-800">
                        {filteredInvoices.map((inv) => (
                          <tr key={inv.id} className="hover:bg-gray-200/60 transition-colors">
                            <td className="py-3 px-4 font-mono font-bold text-blue-700">
                              <button
                                type="button"
                                onClick={() => setSelectedInvoice(inv)}
                                className="hover:underline text-left cursor-pointer"
                                title="View Full Tax Invoice with Logo"
                              >
                                {inv.invoiceNo}
                              </button>
                            </td>
                            <td className="py-3 px-3 font-mono text-slate-700">{inv.date}</td>
                            <td className="py-3 px-3 font-mono text-slate-800">{inv.challanNo}</td>
                            <td className="py-3 px-4">
                              <div className="font-bold text-slate-900">{inv.customerName}</div>
                              <div className="text-[11px] font-mono text-slate-600">
                                {inv.customerGstin}
                              </div>
                            </td>
                            <td className="py-3 px-3 text-right font-mono tabular-nums font-medium">
                              {formatINR(inv.taxableAmount)}
                            </td>
                            <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                              {formatINR(inv.totalGst)}
                            </td>
                            <td className="py-3 px-4 text-right font-mono tabular-nums font-extrabold text-emerald-700">
                              {formatINR(inv.grandTotal)}
                            </td>
                            <td className="py-3 px-3 font-mono text-[11px]">
                              {inv.status === 'PAID' && (
                                <span className="text-emerald-700 font-bold">PAID</span>
                              )}
                              {inv.status === 'UNPAID' && (
                                <span className="text-rose-600 font-bold">UNPAID</span>
                              )}
                              {inv.status === 'PARTIAL' && (
                                <span className="text-amber-700 font-bold">PARTIAL</span>
                              )}
                            </td>
                            <td className="py-3 px-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => handleToggleInvoiceStatus(inv.id)}
                                  className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-gray-50 border border-gray-300 text-slate-700 text-[11px] font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                                >
                                  {inv.status === 'PAID' ? 'Mark Unpaid' : 'Mark Paid'}
                                </button>
                                <button
                                  onClick={() => setSelectedInvoice(inv)}
                                  className="px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-semibold inline-flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                                  title="View Invoice (बिल पहा)"
                                >
                                  <FileText className="w-3 h-3" />
                                  View
                                </button>
                                <button
                                  onClick={() => handleEditInvoice(inv)}
                                  className="px-2.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-semibold inline-flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                                  title="Edit Invoice (बिल एडिट करा)"
                                >
                                  <Pencil className="w-3 h-3" />
                                  Edit
                                </button>
                                <button
                                  onClick={async () => {
                                    await downloadInvoicePdf(inv, companyInfo);
                                    triggerToast(`Invoice ${inv.invoiceNo} PDF downloaded!`);
                                  }}
                                  className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-semibold inline-flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                                  title="Download PDF"
                                >
                                  <Download className="w-3 h-3" />
                                  PDF
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </section>
          )}

          {/* =========================================================
              TAB 4: CUSTOMER MASTER (ग्राहक यादी — ADD, EDIT & DELETE)
             ========================================================= */}
          {activeTab === 'customers' && (
            <section className="space-y-6">
              {/* Add / Edit Customer Form */}
              <form
                onSubmit={handleAddCustomer}
                className={`bg-white border shadow-2xs p-6 rounded-xl space-y-4 ${
                  editingCustomerId ? 'border-amber-500' : 'border-slate-200'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-emerald-600" />
                    <h2 className="text-sm font-bold text-slate-900">
                      {editingCustomerId
                        ? 'Edit Customer Details (ग्राहकाची माहिती बदला)'
                        : 'Customer Master — नवीन औद्योगिक ग्राहक जोडा (Add B2B Client)'}
                    </h2>
                  </div>

                  {editingCustomerId && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingCustomerId(null);
                        setNewCustName('');
                        setNewCustGstin('');
                        setNewCustContact('');
                        setNewCustPhone('');
                        setNewCustAddress('');
                      }}
                      className="px-3 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
                    >
                      Cancel Edit (रद्द करा)
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <input
                    type="text"
                    required
                    value={newCustName}
                    onChange={(e) => setNewCustName(e.target.value)}
                    placeholder="Customer Company Name *"
                    className="bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-900 outline-none focus:border-blue-600"
                  />
                  <input
                    type="text"
                    required
                    value={newCustGstin}
                    onChange={(e) => setNewCustGstin(e.target.value.toUpperCase())}
                    placeholder="GSTIN Number (e.g. 27AABCS1429B1Z1) *"
                    className="bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-semibold text-slate-900 outline-none focus:border-blue-600"
                  />
                  <input
                    type="text"
                    value={newCustContact}
                    onChange={(e) => setNewCustContact(e.target.value)}
                    placeholder="Contact Person Name"
                    className="bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-900 outline-none focus:border-blue-600"
                  />
                  <input
                    type="text"
                    value={newCustPhone}
                    onChange={(e) => setNewCustPhone(e.target.value)}
                    placeholder="Mobile Number"
                    className="bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-semibold text-slate-900 outline-none focus:border-blue-600"
                  />
                  <input
                    type="text"
                    value={newCustAddress}
                    onChange={(e) => setNewCustAddress(e.target.value)}
                    placeholder="MIDC Plot / Factory Address"
                    className="bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-900 outline-none focus:border-blue-600"
                  />
                  <button
                    type="submit"
                    className={`font-bold px-4 py-2.5 rounded-lg text-xs transition-colors cursor-pointer ${
                      editingCustomerId
                        ? 'bg-amber-500 hover:bg-amber-400 text-white'
                        : 'bg-blue-600 hover:bg-blue-500 text-white'
                    }`}
                  >
                    {editingCustomerId
                      ? '✓ Update Customer Details (सेव्ह करा)'
                      : '+ Save Customer to Master'}
                  </button>
                </div>
              </form>

              {/* Customer Directory Table with Admin Edit & Delete */}
              <div className="bg-white border border-slate-200 shadow-2xs rounded-xl overflow-hidden">
                <div className="p-4 border-b border-slate-200 flex justify-between items-center">
                  <h3 className="font-bold text-slate-900 text-sm">
                    Registered Industrial Clients ({customers.length}) — Admin Edit &amp; Delete Enabled
                  </h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                      <tr>
                        <th className="py-3 px-4">COMPANY NAME</th>
                        <th className="py-3 px-3">GSTIN</th>
                        <th className="py-3 px-3">CONTACT PERSON</th>
                        <th className="py-3 px-3">PHONE</th>
                        <th className="py-3 px-4">FACTORY ADDRESS</th>
                        <th className="py-3 px-4 text-right">ADMIN ACTIONS (EDIT / DELETE)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 text-slate-800">
                      {customers.map((c) => (
                        <tr key={c.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-3 px-4 font-bold text-slate-900">{c.name}</td>
                          <td className="py-3 px-3 font-mono font-semibold text-blue-600">{c.gstin}</td>
                          <td className="py-3 px-3 text-slate-700">{c.contactPerson}</td>
                          <td className="py-3 px-3 font-mono text-slate-700">{c.phone}</td>
                          <td className="py-3 px-4 text-slate-600">
                            {c.address}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                type="button"
                                onClick={() => {
                                  handleSelectCustomer(c.id);
                                  setActiveTab('create-invoice');
                                }}
                                className="px-2.5 py-1.5 rounded-lg bg-blue-50 border border-blue-200 hover:bg-blue-600 text-blue-700 hover:text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                              >
                                Create Bill
                              </button>
                              <button
                                type="button"
                                onClick={() => handleStartEditCustomer(c)}
                                className="px-2.5 py-1.5 rounded-lg bg-amber-50 border border-amber-200 hover:bg-amber-100 text-amber-700 text-xs font-semibold inline-flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                                title="Edit Customer"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                                Edit
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteCustomer(c)}
                                className="px-2.5 py-1.5 rounded-lg bg-rose-50 border border-rose-200 hover:bg-rose-100 text-rose-700 text-xs font-semibold inline-flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                                title="Delete Customer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                Delete
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          )}

          {/* =========================================================
              TAB 5: PRODUCT MASTER (COATING SERVICES — ADD, EDIT & DELETE)
             ========================================================= */}
          {activeTab === 'services' && (
            <section className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left 7 Cols: Product / Coating Rate Card with Admin Edit & Delete */}
                <div className="lg:col-span-7 bg-white border border-slate-200 shadow-2xs rounded-xl overflow-hidden">
                  <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h2 className="font-bold text-slate-900 text-sm">
                        Product Master — Coating Services &amp; Rates ({services.length})
                      </h2>
                      <p className="text-xs text-slate-500">
                        Admin can Edit or Delete any coating service, HSN/SAC code, or standard rate
                      </p>
                    </div>
                  </div>
                  <div className="divide-y divide-slate-200">
                    {services.map((srv) => (
                      <div
                        key={srv.id}
                        className={`p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50 transition-colors ${
                          editingServiceId === srv.id ? 'bg-amber-50' : ''
                        }`}
                      >
                        <div className="space-y-0.5 flex-1 min-w-0">
                          <div className="text-xs font-mono font-semibold text-blue-600">
                            {srv.code} · HSN/SAC {srv.sacCode} · {srv.category}
                          </div>
                          <div className="text-sm font-bold text-slate-900">{srv.name}</div>
                          <div className="text-xs text-slate-600">{srv.marathiName}</div>
                          <div className="text-[11px] text-slate-500 pt-0.5">
                            {srv.specDetails}
                          </div>
                        </div>

                        <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0">
                          <div className="sm:text-right">
                            <div className="text-lg font-extrabold font-mono text-emerald-700">
                              {formatINR(srv.standardRate)}
                            </div>
                            <div className="text-xs text-slate-500">
                              per {srv.defaultUnit}
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleStartEditService(srv)}
                              className="px-2.5 py-1 rounded-lg bg-amber-50 border border-amber-200 hover:bg-amber-100 text-amber-700 text-xs font-semibold inline-flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <Pencil className="w-3 h-3" />
                              Edit
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteService(srv)}
                              className="px-2.5 py-1 rounded-lg bg-rose-50 border border-rose-200 hover:bg-rose-100 text-rose-700 text-xs font-semibold inline-flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3 h-3" />
                              Delete
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right 5 Cols: Add/Edit Product Master Form + Estimator */}
                <div className="lg:col-span-5 space-y-6">
                  {/* Add or Edit Coating Product / Service Form */}
                  <form
                    onSubmit={handleAddService}
                    className={`bg-white border shadow-2xs p-5 rounded-xl space-y-3 ${
                      editingServiceId ? 'border-amber-500' : 'border-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-slate-900">
                        {editingServiceId
                          ? 'Edit Product / Coating Service (प्रोडक्ट बदला)'
                          : 'Add New Product / Coating Service (नवीन प्रोडक्ट जोडा)'}
                      </h3>
                      {editingServiceId && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingServiceId(null);
                            setNewServiceName('');
                            setNewServiceMarathi('');
                            setNewServiceSpec('');
                          }}
                          className="text-xs font-semibold text-slate-500 hover:text-slate-900 cursor-pointer"
                        >
                          Cancel
                        </button>
                      )}
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Product / Coating Description (इंग्रजी नाव) *
                      </label>
                      <input
                        type="text"
                        required
                        value={newServiceName}
                        onChange={(e) => setNewServiceName(e.target.value)}
                        placeholder="e.g. MS FRAME FOR POWDER COATING RAL 7035"
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-semibold text-slate-900 outline-none focus:border-blue-600"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                          Marathi Name (मराठी नाव)
                        </label>
                        <input
                          type="text"
                          value={newServiceMarathi}
                          onChange={(e) => setNewServiceMarathi(e.target.value)}
                          placeholder="उदा. पावडर कोटिंग काम"
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-900 outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                          HSN / SAC Code
                        </label>
                        <input
                          type="text"
                          value={newServiceSac}
                          onChange={(e) => setNewServiceSac(e.target.value)}
                          placeholder="998898"
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-mono font-semibold text-slate-900 outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">Category</label>
                        <select
                          value={newServiceCategory}
                          onChange={(e) =>
                            setNewServiceCategory(
                              e.target.value as CoatingService['category']
                            )
                          }
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-semibold text-slate-900 outline-none"
                        >
                          <option value="Powder Coating">Powder Coating</option>
                          <option value="PVD Coating">PVD Coating</option>
                          <option value="Epoxy Coating">Epoxy Coating</option>
                          <option value="Surface Pretreatment">Pretreatment</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">Unit</label>
                        <select
                          value={newServiceUnit}
                          onChange={(e) =>
                            setNewServiceUnit(e.target.value as CoatingService['defaultUnit'])
                          }
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-semibold text-slate-900 outline-none"
                        >
                          <option value="KGS">Per KGS</option>
                          <option value="SQ.FT">Per SQ.FT</option>
                          <option value="NOS">Per NOS</option>
                          <option value="LOT">Per LOT</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">Rate (₹)</label>
                        <input
                          type="number"
                          step="any"
                          required
                          value={newServiceRate}
                          onChange={(e) => setNewServiceRate(e.target.value)}
                          placeholder="Rate ₹"
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-mono font-semibold text-slate-900 outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Technical Specification (Micron / RAL Shade)
                      </label>
                      <input
                        type="text"
                        value={newServiceSpec}
                        onChange={(e) => setNewServiceSpec(e.target.value)}
                        placeholder="Technical Specification (Micron / RAL / Salt Spray Hrs)"
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-900 outline-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className={`w-full font-bold py-2.5 rounded-lg text-xs transition-colors cursor-pointer ${
                        editingServiceId
                          ? 'bg-amber-500 hover:bg-amber-400 text-white'
                          : 'bg-blue-600 hover:bg-blue-500 text-white'
                      }`}
                    >
                      {editingServiceId
                        ? '✓ Update Product / Service Rate (सेव्ह करा)'
                        : '+ Save Product to Master'}
                    </button>
                  </form>

                  {/* Surface Area & Powder Consumption Calculator */}
                  <div className="bg-white border border-slate-200 shadow-2xs p-5 rounded-xl space-y-4">
                    <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
                      <Calculator className="w-4 h-4 text-amber-600" />
                      <div>
                        <h3 className="text-sm font-bold text-slate-900">
                          Sheet Metal Sq.Ft &amp; Powder Estimator
                        </h3>
                        <p className="text-[11px] text-slate-500">
                          Calculate coating area, powder kg required (at 70μm), and instant quotation
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <label className="block font-semibold text-slate-600 mb-1">Length (Feet)</label>
                        <input
                          type="number"
                          min="0.5"
                          step="0.5"
                          value={calcLengthFt}
                          onChange={(e) => setCalcLengthFt(parseFloat(e.target.value) || 0)}
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-mono font-semibold text-slate-900"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-600 mb-1">Width (Feet)</label>
                        <input
                          type="number"
                          min="0.5"
                          step="0.5"
                          value={calcWidthFt}
                          onChange={(e) => setCalcWidthFt(parseFloat(e.target.value) || 0)}
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-mono font-semibold text-slate-900"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-600 mb-1">Total Quantity (Nos)</label>
                        <input
                          type="number"
                          min="1"
                          value={calcQtyPanels}
                          onChange={(e) => setCalcQtyPanels(parseInt(e.target.value, 10) || 0)}
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-mono font-semibold text-slate-900"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-600 mb-1">Rate per Sq.Ft (₹)</label>
                        <input
                          type="number"
                          min="1"
                          value={calcRateSqFt}
                          onChange={(e) => setCalcRateSqFt(parseFloat(e.target.value) || 0)}
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-mono font-semibold text-slate-900"
                        />
                      </div>
                    </div>

                    {(() => {
                      const totalSqFt = calcLengthFt * calcWidthFt * calcQtyPanels;
                      const estPowderKg = totalSqFt / 65; // ~65 sq.ft per kg at 70 microns
                      const estTaxable = totalSqFt * calcRateSqFt;
                      const estWithGst = estTaxable * 1.18;
                      return (
                        <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 space-y-1.5 text-xs">
                          <div className="flex justify-between">
                            <span className="text-slate-600">Total Coating Surface Area:</span>
                            <span className="font-mono font-bold text-slate-900">
                              {totalSqFt.toFixed(1)} Sq.Ft
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-600">Est. Powder Consumption (70μm):</span>
                            <span className="font-mono font-bold text-amber-600">
                              {estPowderKg.toFixed(2)} Kg
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-600">Taxable Estimate:</span>
                            <span className="font-mono font-semibold text-slate-800">
                              {formatINR(estTaxable)}
                            </span>
                          </div>
                          <div className="flex justify-between border-t border-slate-200 pt-1.5 font-extrabold text-emerald-700">
                            <span>Total Quote (Incl. 18% GST):</span>
                            <span className="font-mono">{formatINR(estWithGst)}</span>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* =========================================================
              TAB 6: REPORTS & GST (GSTR-1 & TAX SUMMARY)
             ========================================================= */}
          {activeTab === 'reports' && (
            <section className="space-y-6">
              <div className="bg-white border border-slate-200 shadow-2xs p-6 rounded-xl space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
                  <div>
                    <h2 className="text-lg font-extrabold text-slate-900">
                      Reports &amp; GST Filing Summary (GSTR-1 &amp; कर अहवाल)
                    </h2>
                    <p className="text-xs text-slate-500">
                      Summary of Taxable Value, CGST, SGST, and Invoice-wise GST liability for CA filing
                    </p>
                  </div>
                  <button
                    onClick={handleExportCSV}
                    className="px-4 py-2 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    Download GSTR-1 Excel / CSV
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                    <div className="text-xs font-semibold text-slate-500">Total Taxable Turnover</div>
                    <div className="text-xl font-extrabold font-mono text-slate-900 mt-1">
                      {formatINR(
                        invoices.reduce((acc, i) => acc + i.taxableAmount, 0)
                      )}
                    </div>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                    <div className="text-xs font-semibold text-slate-500">Total CGST + SGST Collected</div>
                    <div className="text-xl font-extrabold font-mono text-blue-600 mt-1">
                      {formatINR(metrics.totalGstCollected)}
                    </div>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                    <div className="text-xs font-semibold text-slate-500">Total Gross Billed (Incl. GST)</div>
                    <div className="text-xl font-extrabold font-mono text-emerald-700 mt-1">
                      {formatINR(metrics.totalSales)}
                    </div>
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* =========================================================
              TAB 7: COMPANY SETTINGS (ADMIN CONTROL PANEL: COMPANY, GST, ADDRESS, BANK, LOGO & USER ACCESS)
             ========================================================= */}
          {activeTab === 'settings' && (
            <section className="space-y-6">
              {/* Top Admin Notice Header */}
              <div className="bg-white border border-blue-200 shadow-2xs p-5 rounded-xl flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-base font-extrabold text-slate-900">
                      Admin Company Settings &amp; User Access Control (ॲडमिन सेटिंग्स व युजर ॲक्सेस)
                    </h2>
                    <p className="text-xs text-slate-500">
                      Manage Company Name, GSTIN, PAN, Factory Address, Bank Details, Company Logo, and Staff User Permissions
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    triggerToast(
                      'सर्व कंपनी सेटिंग्स, लोगो आणि बँक माहिती सेव्ह झाली आहे! (Saved to Invoice Template)'
                    )
                  }
                  className="px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Save All Changes (सेव्ह करा)
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* LEFT 4 COLS: COMPANY LOGO UPLOAD & PREVIEW */}
                <div className="lg:col-span-4 bg-white border border-slate-200 shadow-2xs p-5 rounded-xl space-y-4 flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="border-b border-slate-200 pb-2.5">
                      <h3 className="text-sm font-extrabold text-blue-700 uppercase tracking-wide">
                        1. Company Logo (कंपनीचा लोगो)
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        This logo appears on the top-left of your printed GST Tax Invoice &amp; Sidebar
                      </p>
                    </div>

                    {/* Logo Preview Box */}
                    <div className="flex flex-col items-center justify-center p-6 rounded-xl bg-slate-50 border border-dashed border-slate-300 space-y-3">
                      <VdLogo size="xl" logoUrl={companyInfo.logoUrl} />

                      <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                        <label className="px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors">
                          <Upload className="w-3.5 h-3.5" />
                          <span>Upload New Logo (PNG/JPG)</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              const reader = new FileReader();
                              reader.onload = async () => {
                                if (typeof reader.result === 'string') {
                                  const rawDataUrl = reader.result as string;
                                  const normalizedPng = await renderLogoToPngDataUrl(
                                    rawDataUrl,
                                    400
                                  );
                                  setCompanyInfo((prev) => ({
                                    ...prev,
                                    logoUrl: normalizedPng || rawDataUrl,
                                  }));
                                  triggerToast('नवीन कंपनी लोगो अपलोड झाला आहे! (Logo Updated)');
                                }
                              };
                              reader.readAsDataURL(file);
                            }}
                          />
                        </label>

                        {companyInfo.logoUrl && (
                          <button
                            type="button"
                            onClick={() => {
                              setCompanyInfo((prev) => ({ ...prev, logoUrl: '' }));
                              triggerToast('Default VD Coating emblem restored.');
                            }}
                            className="px-3 py-2 rounded-lg bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-semibold cursor-pointer"
                          >
                            Reset Default Logo
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg text-[11px] text-slate-500">
                    Tip: Upload a square or rectangular company logo (PNG or JPG). It is saved automatically in your browser and printed on every GST Tax Invoice.
                  </div>
                </div>

                {/* RIGHT 8 COLS: COMPANY NAME, GST, PAN, ADDRESS & BANK DETAILS */}
                <div className="lg:col-span-8 bg-white border border-slate-200 shadow-2xs p-5 rounded-xl space-y-5">
                  {/* Section A: Company Name, GSTIN, PAN & Address */}
                  <div className="space-y-3.5">
                    <div className="border-b border-slate-200 pb-2">
                      <h3 className="text-sm font-extrabold text-blue-700 uppercase tracking-wide">
                        2. Company Name, GSTIN &amp; Factory Address (कंपनी नाव, जीएसटी व पत्ता)
                      </h3>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          Company Name (कंपनीचे नाव) *
                        </label>
                        <input
                          type="text"
                          value={companyInfo.name}
                          onChange={(e) =>
                            setCompanyInfo({ ...companyInfo, name: e.target.value })
                          }
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-900 font-semibold focus:border-blue-600 outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          Company Tagline / Specialization
                        </label>
                        <input
                          type="text"
                          value={companyInfo.tagline}
                          onChange={(e) =>
                            setCompanyInfo({ ...companyInfo, tagline: e.target.value })
                          }
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-900 focus:border-blue-600 outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          Company GSTIN (जीएसटी क्रमांक) *
                        </label>
                        <input
                          type="text"
                          value={companyInfo.gstin}
                          onChange={(e) =>
                            setCompanyInfo({
                              ...companyInfo,
                              gstin: e.target.value.toUpperCase(),
                            })
                          }
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 font-mono text-blue-700 font-bold focus:border-blue-600 outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          Company PAN Number (पॅन क्र.) *
                        </label>
                        <input
                          type="text"
                          value={companyInfo.pan}
                          onChange={(e) =>
                            setCompanyInfo({
                              ...companyInfo,
                              pan: e.target.value.toUpperCase(),
                            })
                          }
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 font-mono font-semibold text-slate-900 focus:border-blue-600 outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          Proprietor / Admin Name (प्रोप्रायटर नाव)
                        </label>
                        <input
                          type="text"
                          value={companyInfo.proprietor}
                          onChange={(e) =>
                            setCompanyInfo({ ...companyInfo, proprietor: e.target.value })
                          }
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-900 focus:border-blue-600 outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          Mobile Numbers &amp; Email
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="text"
                            value={companyInfo.phone}
                            onChange={(e) =>
                              setCompanyInfo({ ...companyInfo, phone: e.target.value })
                            }
                            placeholder="Mobile No"
                            className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 font-mono text-slate-900 focus:border-blue-600 outline-none"
                          />
                          <input
                            type="email"
                            value={companyInfo.email}
                            onChange={(e) =>
                              setCompanyInfo({ ...companyInfo, email: e.target.value })
                            }
                            placeholder="Email"
                            className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-900 focus:border-blue-600 outline-none"
                          />
                        </div>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-slate-700 font-semibold mb-1">
                          Factory / Registered Office Address (पूर्ण पत्ता) *
                        </label>
                        <input
                          type="text"
                          value={companyInfo.address}
                          onChange={(e) =>
                            setCompanyInfo({ ...companyInfo, address: e.target.value })
                          }
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-900 focus:border-blue-600 outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Section B: RTGS / NEFT Bank Details */}
                  <div className="space-y-3.5 pt-2 border-t border-slate-200">
                    <div>
                      <h3 className="text-sm font-extrabold text-emerald-700 uppercase tracking-wide">
                        3. Company&apos;s Bank Details for RTGS / NEFT (बँक खात्याचा तपशील)
                      </h3>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          Bank Name (बँकेचे नाव)
                        </label>
                        <input
                          type="text"
                          value={companyInfo.bankName}
                          onChange={(e) =>
                            setCompanyInfo({ ...companyInfo, bankName: e.target.value })
                          }
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-900 focus:border-emerald-600 outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          Branch Name (शाखा)
                        </label>
                        <input
                          type="text"
                          value={companyInfo.branchName}
                          onChange={(e) =>
                            setCompanyInfo({ ...companyInfo, branchName: e.target.value })
                          }
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-900 focus:border-emerald-600 outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          A/C Number (खाते क्र.)
                        </label>
                        <input
                          type="text"
                          value={companyInfo.accountNo}
                          onChange={(e) =>
                            setCompanyInfo({ ...companyInfo, accountNo: e.target.value })
                          }
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 font-mono text-slate-900 font-bold focus:border-emerald-600 outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          IFSC Code
                        </label>
                        <input
                          type="text"
                          value={companyInfo.ifsc}
                          onChange={(e) =>
                            setCompanyInfo({
                              ...companyInfo,
                              ifsc: e.target.value.toUpperCase(),
                            })
                          }
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 font-mono text-slate-900 font-bold focus:border-emerald-600 outline-none"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* =========================================================
                  SECTION 4: OTHER USER ACCESS & ROLE PERMISSIONS (इतर युजर ॲक्सेस व परवानग्या)
                 ========================================================= */}
              <div className="bg-white border border-slate-200 shadow-2xs p-6 rounded-xl space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-3">
                  <div>
                    <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                      <Users className="w-4 h-4 text-blue-600" />
                      <span>
                        4. Other User Access &amp; Role Permissions (इतर युजर्सना ॲक्सेस द्या व कंट्रोल करा)
                      </span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      Add Billing Operators, Accountants, or Plant Supervisors and toggle their exact module permissions
                    </p>
                  </div>
                </div>

                {/* Add New Staff User Form */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!newUserName.trim()) return;
                    const isFullAdmin = newUserRole === 'ADMIN (FULL ACCESS)';
                    const isBilling = newUserRole === 'BILLING OPERATOR';
                    const isAccountant = newUserRole === 'ACCOUNTANT (GST)';

                    const createdUser: StaffUser = {
                      id: `usr-${Date.now()}`,
                      name: newUserName.trim(),
                      emailOrMobile: newUserContact.trim() || '9822000000',
                      role: newUserRole,
                      active: true,
                      permissions: {
                        createInvoice: isFullAdmin || isBilling,
                        editDeleteInvoice: isFullAdmin,
                        manageCustomersAndRates: isFullAdmin || isBilling,
                        viewGstReports: isFullAdmin || isAccountant,
                        manageCompanySettings: isFullAdmin,
                      },
                    };
                    setStaffUsers((prev) => [...prev, createdUser]);
                    setNewUserName('');
                    setNewUserContact('');
                    triggerToast(`User "${createdUser.name}" added with ${createdUser.role} access!`);
                  }}
                  className="p-4 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-3 items-end"
                >
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Staff / User Full Name (युजरचे नाव) *
                    </label>
                    <input
                      type="text"
                      required
                      value={newUserName}
                      onChange={(e) => setNewUserName(e.target.value)}
                      placeholder="e.g. Rahul Patil (Billing)"
                      className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-900 outline-none focus:border-blue-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Mobile No. or Email ID *
                    </label>
                    <input
                      type="text"
                      required
                      value={newUserContact}
                      onChange={(e) => setNewUserContact(e.target.value)}
                      placeholder="9822XXXXXX or email"
                      className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-semibold text-slate-900 outline-none focus:border-blue-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Select User Role (रोल निवडा)
                    </label>
                    <select
                      value={newUserRole}
                      onChange={(e) => setNewUserRole(e.target.value as UserRole)}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-900 outline-none focus:border-blue-600"
                    >
                      <option value="BILLING OPERATOR">BILLING OPERATOR (फक्त बिल बनवणे)</option>
                      <option value="ACCOUNTANT (GST)">ACCOUNTANT (GST रिपोर्ट व बिल पाहणे)</option>
                      <option value="PLANT SUPERVISOR">PLANT SUPERVISOR (जॉब कार्ड ट्रॅकिंग)</option>
                      <option value="ADMIN (FULL ACCESS)">ADMIN (FULL ACCESS - सर्व अधिकार)</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="py-2.5 px-4 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <UserPlus className="w-4 h-4" />
                    + Add User Access
                  </button>
                </form>

                {/* User Permissions Matrix Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                      <tr>
                        <th className="py-3 px-4">USER NAME &amp; CONTACT</th>
                        <th className="py-3 px-3">ROLE</th>
                        <th className="py-3 px-3 text-center">Create Bill</th>
                        <th className="py-3 px-3 text-center">Edit / Delete</th>
                        <th className="py-3 px-3 text-center">Customers &amp; Rates</th>
                        <th className="py-3 px-3 text-center">GST Reports</th>
                        <th className="py-3 px-3 text-center">Admin Settings</th>
                        <th className="py-3 px-3 text-center">STATUS</th>
                        <th className="py-3 px-4 text-right">ACTION</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 text-slate-800">
                      {staffUsers.map((usr) => {
                        const togglePerm = (
                          permKey: keyof StaffUser['permissions']
                        ) => {
                          setStaffUsers((prev) =>
                            prev.map((u) =>
                              u.id === usr.id
                                ? {
                                    ...u,
                                    permissions: {
                                      ...u.permissions,
                                      [permKey]: !u.permissions[permKey],
                                    },
                                  }
                                : u
                            )
                          );
                        };

                        return (
                          <tr key={usr.id} className="hover:bg-slate-50">
                            <td className="py-3 px-4">
                              <div className="font-bold text-slate-900">{usr.name}</div>
                              <div className="text-[11px] font-mono text-slate-500">
                                {usr.emailOrMobile}
                              </div>
                            </td>
                            <td className="py-3 px-3">
                              <span
                                className={`text-[11px] font-bold ${
                                  usr.role === 'ADMIN (FULL ACCESS)'
                                    ? 'text-purple-700'
                                    : 'text-blue-600'
                                }`}
                              >
                                {usr.role}
                              </span>
                            </td>
                            {(
                              [
                                'createInvoice',
                                'editDeleteInvoice',
                                'manageCustomersAndRates',
                                'viewGstReports',
                                'manageCompanySettings',
                              ] as const
                            ).map((permKey) => (
                              <td key={permKey} className="py-3 px-3 text-center">
                                <input
                                  type="checkbox"
                                  checked={usr.permissions[permKey]}
                                  onChange={() => togglePerm(permKey)}
                                  className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
                                />
                              </td>
                            ))}
                            <td className="py-3 px-3 text-center">
                              <button
                                type="button"
                                onClick={() =>
                                  setStaffUsers((prev) =>
                                    prev.map((u) =>
                                      u.id === usr.id ? { ...u, active: !u.active } : u
                                    )
                                  )
                                }
                                className={`px-2.5 py-1 rounded text-[10px] font-bold cursor-pointer ${
                                  usr.active
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                    : 'bg-rose-50 text-rose-700 border border-rose-200'
                                }`}
                              >
                                {usr.active ? 'ACTIVE' : 'DISABLED'}
                              </button>
                            </td>
                            <td className="py-3 px-4 text-right">
                              {usr.id !== 'usr-1' && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setStaffUsers((prev) =>
                                      prev.filter((u) => u.id !== usr.id)
                                    );
                                    triggerToast(`User "${usr.name}" removed.`);
                                  }}
                                  className="p-1.5 rounded text-rose-600 hover:bg-rose-50 cursor-pointer"
                                  title="Remove User"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          )}
        </main>
      </div>

      {/* =========================================================
          MOBILE APP BOTTOM NAVIGATION BAR (FOR ANDROID / iOS PHONES)
         ========================================================= */}
      <nav className="no-print lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 shadow-lg grid grid-cols-6 py-1.5 px-1">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center justify-center py-1 text-[10px] font-semibold ${
            activeTab === 'dashboard' ? 'text-blue-600' : 'text-slate-500'
          }`}
        >
          <LayoutDashboard className="w-4 h-4 mb-0.5" />
          <span>Home</span>
        </button>
        <button
          onClick={() => setActiveTab('invoices')}
          className={`flex flex-col items-center justify-center py-1 text-[10px] font-semibold ${
            activeTab === 'invoices' ? 'text-blue-600' : 'text-slate-500'
          }`}
        >
          <FileText className="w-4 h-4 mb-0.5" />
          <span>Bills</span>
        </button>
        <button
          onClick={() => setActiveTab('create-invoice')}
          className={`flex flex-col items-center justify-center py-1 text-[10px] font-extrabold ${
            activeTab === 'create-invoice' ? 'text-blue-600' : 'text-emerald-600'
          }`}
        >
          <FilePlus2 className="w-5 h-5 mb-0.5" />
          <span>+ Bill</span>
        </button>
        <button
          onClick={() => setActiveTab('customers')}
          className={`flex flex-col items-center justify-center py-1 text-[10px] font-semibold ${
            activeTab === 'customers' ? 'text-blue-600' : 'text-slate-500'
          }`}
        >
          <Users className="w-4 h-4 mb-0.5" />
          <span>Customers</span>
        </button>
        <button
          onClick={() => setActiveTab('services')}
          className={`flex flex-col items-center justify-center py-1 text-[10px] font-semibold ${
            activeTab === 'services' ? 'text-blue-600' : 'text-slate-500'
          }`}
        >
          <Layers className="w-4 h-4 mb-0.5" />
          <span>Products</span>
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`flex flex-col items-center justify-center py-1 text-[10px] font-semibold ${
            activeTab === 'settings' ? 'text-blue-600' : 'text-slate-500'
          }`}
        >
          <Settings className="w-4 h-4 mb-0.5" />
          <span>Settings</span>
        </button>
      </nav>

      {/* =========================================================
          PC, TAB & MOBILE APP INSTALL / SYNC MODAL (STANDALONE PHONE ICON)
         ========================================================= */}
      {showMobileSyncModal && (
        <div className="no-print fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-2xl text-slate-900">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5">
                <Smartphone className="w-5 h-5 text-blue-600" />
                <h3 className="text-base font-extrabold text-slate-900">
                  Direct Phone Icon App Install (फोन आयकॉनमध्ये इन्स्टॉल)
                </h3>
              </div>
              <button
                onClick={() => setShowMobileSyncModal(false)}
                className="text-slate-500 hover:text-slate-900 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Standalone Phone Home Screen App Icon Preview */}
            <div className="flex items-center gap-3.5 p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <VdLogo size="lg" logoUrl={companyInfo.logoUrl} />
              <div className="space-y-0.5 text-xs">
                <div className="font-extrabold text-slate-900 text-sm">
                  VD Coating (Standalone Phone App)
                </div>
                <div className="text-emerald-700 font-bold text-[11px]">
                  ✓ Chrome न उघडता थेट फोन आयकॉनमधून फुल-स्क्रीन ॲप उघडते
                </div>
                <div className="text-slate-500 text-[11px]">
                  No Browser Address Bar · Direct Home Screen Icon
                </div>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
              {isInstallable ? (
                <button
                  onClick={async () => {
                    const ok = await install();
                    if (ok) {
                      triggerToast(
                        'VD Coating App तुमच्या फोन/PC आयकॉनमध्ये इन्स्टॉल झाले आहे!'
                      );
                      setShowMobileSyncModal(false);
                    }
                  }}
                  className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer"
                >
                  <DownloadCloud className="w-4 h-4" />
                  📲 Install Direct to Phone / PC Home Screen Icon (आता इन्स्टॉल करा)
                </button>
              ) : (
                <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 space-y-2.5">
                  <p className="text-blue-800 font-bold text-xs">
                    फोनवर स्वतंत्र ॲप आयकॉन (Phone Icon) म्हणून इन्स्टॉल करण्यासाठी:
                  </p>
                  {isInIframe && (
                    <a
                      href={`${window.location.origin}/?install=1`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-sm transition-colors"
                    >
                      <DownloadCloud className="w-4 h-4" />
                      1-Tap Launch &amp; Install Phone Icon (येथे क्लिक करून Install दाबा)
                    </a>
                  )}
                  <p className="text-[11px] text-slate-700">
                    एकदा फोनवर <strong>&quot;Install App / Add to Home Screen&quot;</strong> केल्यावर तुमच्या मोबाईलमध्ये <strong>VD Coating</strong> चा स्वतंत्र आयकॉन तयार होतो. त्यानंतर ॲप उघडताना Chrome उघडणार नाही, थेट ॲप उघडेल!
                  </p>
                </div>
              )}

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
                <div className="font-bold text-slate-900">
                  📱 मोबाईलमध्ये Direct App Icon कसा घ्यावा (फक्त १ वेळा):
                </div>
                <p className="text-slate-600 text-[11px]">
                  १) वरच्या <strong>Install</strong> बटनावर क्लिक करा किंवा मोबाईलमधील <strong>⋮</strong> मेनूमधून{' '}
                  <strong className="text-slate-900">&quot;Install App (Add to Home Screen)&quot;</strong> निवडा.
                  <br />
                  २) तुमच्या फोनच्या स्क्रीनवर <strong>VD Coating</strong> चा आयकॉन येईल — त्यावर टॅप केल्यावर Chrome शिवाय थेट बिलिंग ॲप चालू होईल.
                </p>
              </div>

              <div className="flex items-center gap-2 text-emerald-700 text-[11px] font-bold">
                <Check className="w-4 h-4" />
                <span>Standalone Mode Active · Opens Without Chrome Address Bar</span>
              </div>
            </div>

            <button
              onClick={() => setShowMobileSyncModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold cursor-pointer"
            >
              Close (बंद करा)
            </button>
          </div>
        </div>
      )}

      {/* Printable GST Tax Invoice Modal */}
      <InvoicePrintModal
        invoice={selectedInvoice}
        companyInfo={companyInfo}
        onClose={() => setSelectedInvoice(null)}
        onToggleStatus={handleToggleInvoiceStatus}
        onDuplicateInvoice={handleDuplicateInvoice}
        onEditInvoice={handleEditInvoice}
      />
    </div>
  );
}

