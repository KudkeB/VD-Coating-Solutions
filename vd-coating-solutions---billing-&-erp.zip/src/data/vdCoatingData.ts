export type InvoiceStatus = 'PAID' | 'UNPAID' | 'PARTIAL' | 'CANCELLED';

export interface InvoiceLineItem {
  id: string;
  serviceId: string;
  serviceName: string;
  sacCode: string; // e.g., 998898
  partSpecification: string; // e.g. "MS FRAME FOR POWDER COATING RAL 7035"
  unit: 'KGS' | 'SQ.FT' | 'NOS' | 'LOT' | 'MTR' | 'SET' | 'Kg' | 'Sq.Ft' | 'Nos' | 'Lot';
  qty: number;
  rate: number;
  amount: number;
  gstApplicable?: boolean; // true = GST: YES, false = GST: NO
  halfGstRate?: 6 | 9 | 12; // 6% (12%), 9% (18%), 12% (24%)
}

export interface Invoice {
  id: string;
  invoiceNo: string; // e.g., 2026-27-01 or VD/26-27/001
  date: string;
  dueDate: string;
  challanNo: string;
  challanDate?: string;
  poNumber: string;
  poDate?: string;
  vehicleNo: string;
  transportMode?: string;
  reverseCharge?: 'NO' | 'YES';
  customerId: string;
  customerName: string;
  customerGstin: string;
  customerPan?: string;
  customerContact?: string;
  customerAddress: string;
  consigneeName?: string;
  consigneeAddress?: string;
  consigneeGstin?: string;
  consigneeContact?: string;
  stateCode: string; // '27' for Maharashtra (CGST + SGST), else IGST
  halfGstRate?: 6 | 9 | 12; // 6% (12% Total), 9% (18% Total), 12% (24% Total)
  items: InvoiceLineItem[];
  taxableAmount: number;
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
  totalGst: number;
  roundOff: number;
  grandTotal: number;
  amountPaid: number;
  status: InvoiceStatus;
  paymentMode?: string;
  notes?: string;
}

export interface Customer {
  id: string;
  name: string;
  gstin: string;
  pan?: string;
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  stateCode: string;
  openingBalance: number;
}

export interface CoatingService {
  id: string;
  code: string;
  name: string;
  marathiName: string;
  sacCode: string;
  category: 'Powder Coating' | 'PVD Coating' | 'Epoxy Coating' | 'Surface Pretreatment';
  defaultUnit: 'KGS' | 'SQ.FT' | 'NOS' | 'LOT';
  standardRate: number;
  gstPercent: number;
  specDetails: string;
}

export interface JobOrder {
  id: string;
  jobCardNo: string;
  receivedDate: string;
  customerName: string;
  partName: string;
  coatingType: string;
  shadeCode: string;
  weightOrQty: string;
  stage: '7-Tank Pretreatment' | 'Powder / PVD Booth' | 'Curing Oven (200°C)' | 'QC & Ready for Dispatch';
  challanNo: string;
}

export interface CompanyProfileConfig {
  name: string;
  tagline: string;
  gstin: string;
  pan: string;
  proprietor: string;
  phone: string;
  email: string;
  address: string;
  state: string;
  stateCode: string;
  bankName: string;
  branchName: string;
  accountNo: string;
  ifsc: string;
  logoUrl?: string;
}

export type UserRole =
  | 'ADMIN (FULL ACCESS)'
  | 'BILLING OPERATOR'
  | 'ACCOUNTANT (GST)'
  | 'PLANT SUPERVISOR';

export interface StaffUser {
  id: string;
  name: string;
  emailOrMobile: string;
  role: UserRole;
  active: boolean;
  permissions: {
    createInvoice: boolean;
    editDeleteInvoice: boolean;
    manageCustomersAndRates: boolean;
    viewGstReports: boolean;
    manageCompanySettings: boolean;
  };
}

export const INITIAL_STAFF_USERS: StaffUser[] = [
  {
    id: 'usr-1',
    name: 'A. V. Darkashe',
    emailOrMobile: '9096313193',
    role: 'ADMIN (FULL ACCESS)',
    active: true,
    permissions: {
      createInvoice: true,
      editDeleteInvoice: true,
      manageCustomersAndRates: true,
      viewGstReports: true,
      manageCompanySettings: true,
    },
  },
  {
    id: 'usr-2',
    name: 'Sagar Kulkarni (Billing Desk)',
    emailOrMobile: '9822114455',
    role: 'BILLING OPERATOR',
    active: true,
    permissions: {
      createInvoice: true,
      editDeleteInvoice: false,
      manageCustomersAndRates: true,
      viewGstReports: false,
      manageCompanySettings: false,
    },
  },
  {
    id: 'usr-3',
    name: 'CA Pravin Deshpande',
    emailOrMobile: 'ca.pravin@gstpune.in',
    role: 'ACCOUNTANT (GST)',
    active: true,
    permissions: {
      createInvoice: false,
      editDeleteInvoice: false,
      manageCustomersAndRates: false,
      viewGstReports: true,
      manageCompanySettings: false,
    },
  },
];

export const COMPANY_PROFILE: CompanyProfileConfig = {
  name: 'VD COATING SOLUTIONS',
  tagline: 'Specialist in Industrial Powder Coating, PVD & Surface Finishing',
  gstin: '27DOHPD0022P1Z0',
  pan: 'DOHPD0022P',
  proprietor: 'A. V. Darkashe',
  phone: '9096313193',
  email: 'vdcoatingsolutions.pune@gmail.com',
  address: 'Anukramank 51/2/5, Near Asaram Bapu Ashram, Alandi (M Cl), Tal-Khed, Dist-Pune, Maharashtra - 412105',
  state: 'Maharashtra',
  stateCode: '27',
  bankName: 'Bank of Maharashtra',
  branchName: 'Alandi (Khed)',
  accountNo: '60384512908',
  ifsc: 'MAHB0001423',
  logoUrl: '',
};

export function extractPanFromGstin(gstin: string): string {
  const cleaned = (gstin || '').trim().toUpperCase();
  if (cleaned.length >= 12) {
    return cleaned.slice(2, 12);
  }
  return '—';
}

export function formatDateDDMMYYYY(isoDate?: string): string {
  if (!isoDate) return '-';
  const parts = isoDate.split('-');
  if (parts.length === 3 && parts[0].length === 4) {
    return `${parts[2]}-${parts[1]}-${parts[0]}`;
  }
  return isoDate;
}

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cust-1',
    name: 'SHREE ENGINEERING WORKS',
    gstin: '27AABCS1429B1Z1',
    pan: 'AABCS1429B',
    contactPerson: 'Rajesh Kulkarni',
    phone: '9822045120',
    email: 'accounts@shreeengpune.in',
    address: 'PLOT G-42, CHAKAN MIDC PHASE II, TAL-KHED DIST PUNE',
    city: 'Pune - 410501',
    stateCode: '27',
    openingBalance: 0,
  },
  {
    id: 'cust-2',
    name: 'APEX AUTO COMPONENTS PVT. LTD.',
    gstin: '27AADCA8921K1Z5',
    pan: 'AADCA8921K',
    contactPerson: 'Sandeep Deshmukh',
    phone: '9890112233',
    email: 'purchase@apexautocomp.com',
    address: 'SECTOR 10, BHOSARI INDUSTRIAL ESTATE, PIMPRI-CHINCHWAD DIST PUNE',
    city: 'Pune - 411026',
    stateCode: '27',
    openingBalance: 21240,
  },
  {
    id: 'cust-3',
    name: 'PRECISION TOOLS & STAMPINGS LTD.',
    gstin: '27AAECP4410M1Z9',
    pan: 'AAECP4410M',
    contactPerson: 'Vikram Joshi',
    phone: '9765400911',
    email: 'billing@precisiontools.co.in',
    address: 'GATE NO. 312, TALAWADE IT & MECHANICAL PARK, DIST PUNE',
    city: 'Pune - 411062',
    stateCode: '27',
    openingBalance: 44800,
  },
  {
    id: 'cust-4',
    name: 'KALYANI HEAVY FABRICATION LLP',
    gstin: '27AAJFK7732N1Z2',
    pan: 'AAJFK7732N',
    contactPerson: 'Mahesh Patil',
    phone: '9422088190',
    email: 'dispatch@kalyanifab.in',
    address: 'MARKAL INDUSTRIAL ZONE, ALANDI-MARKAL ROAD, TAL-KHED DIST PUNE',
    city: 'Pune - 412105',
    stateCode: '27',
    openingBalance: 46360,
  },
  {
    id: 'cust-5',
    name: 'MECON SYSTEMS',
    gstin: '27AGJPA8641A1ZR',
    pan: 'AGJPA8641A',
    contactPerson: 'Nitin Shinde',
    phone: '9822000000',
    email: 'accounts@meconsystems.in',
    address: 'GAT NO 62/3/A AT-POST CHIMBLI TAL-KHED DIST PUNE',
    city: 'Pune - 412105',
    stateCode: '27',
    openingBalance: 0,
  },
];

export const INITIAL_SERVICES: CoatingService[] = [
  {
    id: 'srv-1',
    code: 'PC-RAL-STD',
    name: 'MS FRAME FOR POWDER COATING (7-TANK PROCESS)',
    marathiName: 'इंडस्ट्रियल पावडर कोटिंग काम',
    sacCode: '998898',
    category: 'Powder Coating',
    defaultUnit: 'KGS',
    standardRate: 45,
    gstPercent: 18,
    specDetails: '60–80 Micron Pure Polyester / Epoxy Polyester RAL Shade with 7-Tank Zinc Phosphating',
  },
  {
    id: 'srv-2',
    code: 'PC-SQFT-PNL',
    name: 'SHEET METAL CONTROL PANEL POWDER COATING',
    marathiName: 'पॅनेल बॉक्स स्ट्रक्चर पावडर कोटिंग',
    sacCode: '998898',
    category: 'Powder Coating',
    defaultUnit: 'SQ.FT',
    standardRate: 28,
    gstPercent: 18,
    specDetails: 'RAL 7032 / RAL 7035 Siemens Grey Pebble Structure Finish (70–90 Micron)',
  },
  {
    id: 'srv-3',
    code: 'PVD-GOLD-TI',
    name: 'PVD PROTECTIVE TITANIUM GOLD / ROSE GOLD COATING',
    marathiName: 'पीव्हीडी प्रोटेक्टिव्ह कोटिंग (SS/Brass)',
    sacCode: '998898',
    category: 'PVD Coating',
    defaultUnit: 'NOS',
    standardRate: 185,
    gstPercent: 18,
    specDetails: 'High-Vacuum Physical Vapor Deposition TiN / ZrN Architectural & Die Surface Coating',
  },
  {
    id: 'srv-4',
    code: 'EPX-CHEM-2C',
    name: 'HEAVY-DUTY EPOXY ANTI-CORROSIVE COATING WORK',
    marathiName: 'इपॉक्सी अँटी-करोझिव्ह कोटिंग',
    sacCode: '998898',
    category: 'Epoxy Coating',
    defaultUnit: 'SQ.FT',
    standardRate: 62,
    gstPercent: 18,
    specDetails: '120 Micron High-Build Epoxy Primer + Polyurethane Topcoat (Salt Spray 500+ Hrs)',
  },
  {
    id: 'srv-5',
    code: 'PRE-PHOS-7T',
    name: 'DEGREASING, DERUSTING & ZINC PHOSPHATING JOB WORK',
    marathiName: 'डीग्रेसिंग व झिंक फॉस्फेटिंग ट्रीटमेंट',
    sacCode: '998898',
    category: 'Surface Pretreatment',
    defaultUnit: 'KGS',
    standardRate: 18,
    gstPercent: 18,
    specDetails: '7-Tank Chemical Surface Pretreatment & Passivation before Painting',
  },
];

export const INITIAL_INVOICES: Invoice[] = [
  {
    id: 'inv-1',
    invoiceNo: '2026-27-05',
    date: '2026-10-09',
    dueDate: '2026-10-24',
    challanNo: '385',
    challanDate: '2026-10-09',
    poNumber: 'SEW/PO/2026/114',
    poDate: '2026-10-05',
    vehicleNo: 'MH-14-JL-4921',
    transportMode: 'Road / Tempo',
    reverseCharge: 'NO',
    customerId: 'cust-1',
    customerName: 'SHREE ENGINEERING WORKS',
    customerGstin: '27AABCS1429B1Z1',
    customerPan: 'AABCS1429B',
    customerContact: '9822045120',
    customerAddress: 'PLOT G-42, CHAKAN MIDC PHASE II, TAL-KHED DIST PUNE',
    stateCode: '27',
    items: [
      {
        id: 'li-1',
        serviceId: 'srv-1',
        serviceName: 'MS FRAME FOR POWDER COATING RAL 9005 MATTE BLACK',
        sacCode: '998898',
        partSpecification: 'Heavy MS Brackets & Base Frames (75 Micron)',
        unit: 'KGS',
        qty: 720,
        rate: 45,
        amount: 32400,
      },
    ],
    taxableAmount: 32400,
    cgstAmount: 2916,
    sgstAmount: 2916,
    igstAmount: 0,
    totalGst: 5832,
    roundOff: -2,
    grandTotal: 38230,
    amountPaid: 38230,
    status: 'PAID',
    notes: 'Material dispatched via Road / Tempo MH-14-JL-4921.',
  },
  {
    id: 'inv-2',
    invoiceNo: '2026-27-04',
    date: '2026-10-08',
    dueDate: '2026-10-23',
    challanNo: '382',
    challanDate: '2026-10-08',
    poNumber: '-',
    poDate: '-',
    vehicleNo: 'MH-12-QW-7710',
    transportMode: 'Road / Tempo',
    reverseCharge: 'NO',
    customerId: 'cust-2',
    customerName: 'APEX AUTO COMPONENTS PVT. LTD.',
    customerGstin: '27AADCA8921K1Z5',
    customerPan: 'AADCA8921K',
    customerContact: '9890112233',
    customerAddress: 'SECTOR 10, BHOSARI INDUSTRIAL ESTATE, PIMPRI-CHINCHWAD DIST PUNE',
    stateCode: '27',
    items: [
      {
        id: 'li-2',
        serviceId: 'srv-1',
        serviceName: 'TUBULAR CHASSIS FOR POWDER COATING RAL 3020',
        sacCode: '998898',
        partSpecification: 'Traffic Red Glossy Finish',
        unit: 'KGS',
        qty: 400,
        rate: 45,
        amount: 18000,
      },
    ],
    taxableAmount: 18000,
    cgstAmount: 1620,
    sgstAmount: 1620,
    igstAmount: 0,
    totalGst: 3240,
    roundOff: 0,
    grandTotal: 21240,
    amountPaid: 0,
    status: 'UNPAID',
    notes: 'Payment due within 15 days from date of submission.',
  },
  {
    id: 'inv-3',
    invoiceNo: '2026-27-03',
    date: '2026-09-26',
    dueDate: '2026-10-11',
    challanNo: '351',
    challanDate: '2026-09-26',
    poNumber: 'PTS/JOB/442',
    poDate: '2026-09-24',
    vehicleNo: 'MH-14-HG-2319',
    transportMode: 'Road / Tempo',
    reverseCharge: 'NO',
    customerId: 'cust-3',
    customerName: 'PRECISION TOOLS & STAMPINGS LTD.',
    customerGstin: '27AAECP4410M1Z9',
    customerPan: 'AAECP4410M',
    customerContact: '9765400911',
    customerAddress: 'GATE NO. 312, TALAWADE IT & MECHANICAL PARK, DIST PUNE',
    stateCode: '27',
    items: [
      {
        id: 'li-3',
        serviceId: 'srv-3',
        serviceName: 'PVD PROTECTIVE TITANIUM GOLD COATING ON SS GUIDES',
        sacCode: '998898',
        partSpecification: 'SS 304 Precision Die Guides & Fixtures',
        unit: 'NOS',
        qty: 205,
        rate: 185,
        amount: 37925,
      },
    ],
    taxableAmount: 37925,
    cgstAmount: 3413.25,
    sgstAmount: 3413.25,
    igstAmount: 0,
    totalGst: 6826.5,
    roundOff: 48.5,
    grandTotal: 44800,
    amountPaid: 0,
    status: 'UNPAID',
    notes: 'Batch certified with ultrasonic cleaning prior to PVD chamber cycle.',
  },
  {
    id: 'inv-4',
    invoiceNo: '2026-27-02',
    date: '2026-09-18',
    dueDate: '2026-10-03',
    challanNo: '332',
    challanDate: '2026-09-18',
    poNumber: 'KHF/2026/301',
    poDate: '2026-09-15',
    vehicleNo: 'MH-14-AZ-9088',
    transportMode: 'Road / Tempo',
    reverseCharge: 'NO',
    customerId: 'cust-4',
    customerName: 'KALYANI HEAVY FABRICATION LLP',
    customerGstin: '27AAJFK7732N1Z2',
    customerPan: 'AAJFK7732N',
    customerContact: '9422088190',
    customerAddress: 'MARKAL INDUSTRIAL ZONE, ALANDI-MARKAL ROAD, TAL-KHED DIST PUNE',
    stateCode: '27',
    items: [
      {
        id: 'li-4',
        serviceId: 'srv-4',
        serviceName: 'HEAVY-DUTY EPOXY ANTI-CORROSIVE COATING WORK',
        sacCode: '998898',
        partSpecification: 'Generator Skids & Chemical Tank Channels — 120 Micron Epoxy Grey',
        unit: 'SQ.FT',
        qty: 2250,
        rate: 62,
        amount: 139500,
      },
    ],
    taxableAmount: 139500,
    cgstAmount: 12555,
    sgstAmount: 12555,
    igstAmount: 0,
    totalGst: 25110,
    roundOff: 0,
    grandTotal: 164610,
    amountPaid: 118250,
    status: 'PARTIAL',
    notes: 'Part payment of ₹1,18,250 received via NEFT; balance ₹46,360 pending.',
  },
  {
    id: 'inv-5',
    invoiceNo: '2026-27-01',
    date: '2026-09-05',
    dueDate: '2026-09-20',
    challanNo: '310',
    challanDate: '2026-09-05',
    poNumber: '-',
    poDate: '-',
    vehicleNo: '-',
    transportMode: 'Road / Tempo',
    reverseCharge: 'NO',
    customerId: 'cust-5',
    customerName: 'MECON SYSTEMS',
    customerGstin: '27AGJPA8641A1ZR',
    customerPan: 'AGJPA8641A',
    customerContact: '9822000000',
    customerAddress: 'GAT NO 62/3/A AT-POST CHIMBLI TAL-KHED DIST PUNE',
    stateCode: '27',
    items: [
      {
        id: 'li-5',
        serviceId: 'srv-2',
        serviceName: 'MS FRAME & ENCLOSURE FOR POWDER COATING RAL 7035',
        sacCode: '998898',
        partSpecification: 'Structure Finish Control Enclosures',
        unit: 'SQ.FT',
        qty: 5434,
        rate: 28,
        amount: 152152,
      },
    ],
    taxableAmount: 152152,
    cgstAmount: 13693.68,
    sgstAmount: 13693.68,
    igstAmount: 0,
    totalGst: 27387.36,
    roundOff: 18.12,
    grandTotal: 179557.48,
    amountPaid: 179557.48,
    status: 'PAID',
    notes: 'Full payment settled via RTGS.',
  },
];

export const INITIAL_JOB_ORDERS: JobOrder[] = [
  {
    id: 'job-1',
    jobCardNo: 'JC-26/412',
    receivedDate: '2026-10-09',
    customerName: 'SHREE ENGINEERING WORKS',
    partName: 'CNC Laser Cut Base Plates (Lot #18)',
    coatingType: 'Powder Coating',
    shadeCode: 'RAL 7035 Siemens Grey',
    weightOrQty: '640 KGS',
    stage: 'Curing Oven (200°C)',
    challanNo: 'Challan 385',
  },
  {
    id: 'job-2',
    jobCardNo: 'JC-26/413',
    receivedDate: '2026-10-09',
    customerName: 'MECON SYSTEMS',
    partName: 'MS Frame for Powder Coating',
    coatingType: '7-Tank + Powder Coat',
    shadeCode: 'RAL 9005 Jet Black Matte',
    weightOrQty: '38.75 KGS',
    stage: '7-Tank Pretreatment',
    challanNo: 'Challan 386',
  },
  {
    id: 'job-3',
    jobCardNo: 'JC-26/411',
    receivedDate: '2026-10-08',
    customerName: 'PRECISION TOOLS & STAMPINGS LTD.',
    partName: 'SS Architectural Louvers',
    coatingType: 'PVD Titanium Coating',
    shadeCode: 'Champagne Gold TiN',
    weightOrQty: '140 NOS',
    stage: 'QC & Ready for Dispatch',
    challanNo: 'Challan 380',
  },
];

// Utility to convert Rupees into exact words like "Eight Hundred and Twenty Three Rupees Only"
export function numberToIndianRupeesWords(amount: number): string {
  const rounded = Math.round(amount);
  if (rounded === 0) return 'Zero Rupees Only';

  const ones = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen'
  ];
  const tens = [
    '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'
  ];

  function convertLessThanThousand(n: number): string {
    if (n === 0) return '';
    if (n < 20) return ones[n];
    if (n < 100) {
      return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + ones[n % 10] : '');
    }
    return (
      ones[Math.floor(n / 100)] +
      ' Hundred' +
      (n % 100 !== 0 ? ' and ' + convertLessThanThousand(n % 100) : '')
    );
  }

  let num = rounded;
  const crore = Math.floor(num / 10000000);
  num %= 10000000;
  const lakh = Math.floor(num / 100000);
  num %= 100000;
  const thousand = Math.floor(num / 1000);
  num %= 1000;
  const remainder = num;

  const parts: string[] = [];
  if (crore > 0) parts.push(`${convertLessThanThousand(crore)} Crore`);
  if (lakh > 0) parts.push(`${convertLessThanThousand(lakh)} Lakh`);
  if (thousand > 0) parts.push(`${convertLessThanThousand(thousand)} Thousand`);
  if (remainder > 0) parts.push(convertLessThanThousand(remainder));

  return `${parts.join(' ')} Rupees Only`;
}

export function formatINR(value: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

