import { jsPDF } from 'jspdf';
import {
  Invoice,
  CompanyProfileConfig,
  COMPANY_PROFILE,
  numberToIndianRupeesWords,
  extractPanFromGstin,
  formatDateDDMMYYYY,
} from '../data/vdCoatingData';
import { renderLogoToPngDataUrl } from '../components/VdLogo';

function drawVectorVdEmblemFallback(doc: jsPDF, x: number, y: number, size: number) {
  const cx = x + size / 2;
  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.35);
  doc.rect(x, y, size, size, 'FD');

  // Outer Metallic Shield
  doc.setFillColor(30, 41, 59);
  doc.setDrawColor(100, 116, 139);
  doc.setLineWidth(0.5);
  doc.triangle(cx, y + 2.2, x + size - 3, y + 6.5, x + 3, y + 6.5, 'FD');
  doc.triangle(x + 3, y + 6.5, x + size - 3, y + 6.5, cx, y + size - 2.2, 'FD');

  // Inner Bright Shield
  doc.setFillColor(248, 250, 252);
  doc.triangle(cx, y + 3.6, x + size - 4.5, y + 7.2, x + 4.5, y + 7.2, 'F');
  doc.triangle(x + 4.5, y + 7.2, x + size - 4.5, y + 7.2, cx, y + size - 4, 'F');

  // Bold VD Monogram
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12.5);
  doc.setTextColor(15, 23, 42);
  doc.text('VD', cx, y + size / 2 + 2.2, { align: 'center' });

  // Deep Blue Orbital Swoosh Band Across Shield
  doc.setDrawColor(37, 99, 235);
  doc.setLineWidth(1.4);
  doc.line(x + 2, y + size - 5.5, x + size - 2, y + 6.5);

  // Starburst Dot at Top Right
  doc.setFillColor(56, 189, 248);
  doc.circle(x + size - 3.8, y + 4.8, 1.1, 'F');

  doc.setLineWidth(0.35);
  doc.setDrawColor(15, 23, 42);
}

export async function downloadInvoicePdf(
  invoice: Invoice,
  companyInfo: CompanyProfileConfig = COMPANY_PROFILE,
  copyType: string = 'ORIGINAL FOR RECIPIENT'
): Promise<void> {
  const logoPngDataUrl = await renderLogoToPngDataUrl(companyInfo.logoUrl, 360);

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageW = 210;
  const margin = 10;
  const contentW = pageW - margin * 2; // 190mm
  const topY = 10;
  const totalBoxH = 272;
  let y = topY;

  const customerPan = invoice.customerPan || extractPanFromGstin(invoice.customerGstin);
  const totalQty = invoice.items.reduce((sum, item) => sum + (Number(item.qty) || 0), 0);
  const exactTotalBeforeRound = Number((invoice.taxableAmount + invoice.totalGst).toFixed(2));

  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.35);

  // =========================================================================
  // 1. TOP TITLE BAR (8.5mm)
  // =========================================================================
  const titleBarH = 8.5;
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentW, titleBarH, 'F');
  doc.line(margin, y + titleBarH, margin + contentW, y + titleBarH);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(51, 65, 85);
  doc.text('GST TAX INVOICE (RULE 46 OF CGST RULES)', margin + 3, y + 5.6);

  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('TAX INVOICE', margin + contentW / 2, y + 5.8, { align: 'center' });

  doc.setFontSize(7.5);
  doc.setTextColor(30, 41, 59);
  doc.text(copyType, margin + contentW - 3, y + 5.6, { align: 'right' });

  y += titleBarH;

  // =========================================================================
  // 2. COMPANY HEADER (Left 112mm) + INVOICE METADATA (Right 78mm)
  // =========================================================================
  const headerH = 38;
  const splitX = margin + 112;

  // Bottom GSTIN/PAN strip inside Left Company Cell (fill before lines!)
  const gstStripH = 7.5;
  doc.setFillColor(248, 250, 252);
  doc.rect(margin, y + headerH - gstStripH, 112, gstStripH, 'F');

  // Draw Company Header & Metadata divider lines
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.35);
  doc.line(splitX, y, splitX, y + headerH);
  doc.line(margin, y + headerH - gstStripH, splitX, y + headerH - gstStripH);
  doc.line(margin, y + headerH, margin + contentW, y + headerH);

  // Logo Box on Left (22mm x 22mm) with crisp border
  const logoX = margin + 3;
  const logoY = y + 3.2;
  const logoSize = 22;
  if (logoPngDataUrl && logoPngDataUrl.startsWith('data:image/png')) {
    try {
      doc.setFillColor(255, 255, 255);
      doc.setDrawColor(15, 23, 42);
      doc.setLineWidth(0.35);
      doc.rect(logoX, logoY, logoSize, logoSize, 'FD');
      doc.addImage(logoPngDataUrl, 'PNG', logoX + 0.5, logoY + 0.5, logoSize - 1, logoSize - 1);
    } catch {
      drawVectorVdEmblemFallback(doc, logoX, logoY, logoSize);
    }
  } else {
    drawVectorVdEmblemFallback(doc, logoX, logoY, logoSize);
  }

  // Company Text Info (strictly bounded within 81mm so it never touches splitX)
  const compX = margin + 28;
  const maxCompTextW = 81;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12.5);
  doc.setTextColor(15, 23, 42);
  doc.text(companyInfo.name.toUpperCase(), compX, y + 7.2);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.3);
  doc.setTextColor(51, 65, 85);
  const addrLines = doc.splitTextToSize(companyInfo.address, maxCompTextW).slice(0, 2);
  doc.text(addrLines, compX, y + 11.8);

  const afterAddrY = y + 11.8 + addrLines.length * 3.5;
  doc.text(
    `Contact: ${companyInfo.phone}  |  State: ${companyInfo.state} (${companyInfo.stateCode})`,
    compX,
    afterAddrY
  );
  const emailLine = doc.splitTextToSize(`Email: ${companyInfo.email}`, maxCompTextW)[0];
  doc.text(emailLine, compX, afterAddrY + 3.8);

  // GSTIN & PAN text inside bottom strip
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.text(`GSTIN: ${companyInfo.gstin}`, margin + 3, y + headerH - 2.6);
  doc.text(`PAN: ${companyInfo.pan}`, splitX - 3, y + headerH - 2.6, { align: 'right' });

  // Right Metadata 5x2 Grid
  const metaColW = 39;
  const metaRowH = headerH / 5; // 7.6mm each
  const metaMidX = splitX + metaColW;
  doc.line(metaMidX, y, metaMidX, y + headerH);

  const metaRows = [
    [
      { label: 'INVOICE NO:', val: invoice.invoiceNo },
      { label: 'DATED:', val: formatDateDDMMYYYY(invoice.date) },
    ],
    [
      { label: 'CHALLAN NO:', val: invoice.challanNo || '-' },
      { label: 'CHALLAN DATE:', val: formatDateDDMMYYYY(invoice.challanDate || invoice.date) },
    ],
    [
      { label: 'P.O. NUMBER:', val: invoice.poNumber || '-' },
      {
        label: 'P.O. DATE:',
        val:
          invoice.poDate && invoice.poDate !== '-' ? formatDateDDMMYYYY(invoice.poDate) : '-',
      },
    ],
    [
      {
        label: 'PLACE OF SUPPLY:',
        val: invoice.stateCode === '27' ? 'MAHARASHTRA (27)' : `STATE (${invoice.stateCode})`,
      },
      { label: 'REVERSE CHARGE:', val: invoice.reverseCharge || 'NO' },
    ],
    [
      { label: 'VEHICLE NO:', val: invoice.vehicleNo || '-' },
      { label: 'TRANSPORT:', val: invoice.transportMode || 'Road / Tempo' },
    ],
  ];

  metaRows.forEach((pair, rIdx) => {
    const ry = y + rIdx * metaRowH;
    if (rIdx > 0) {
      doc.line(splitX, ry, margin + contentW, ry);
    }
    // Col 1
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6);
    doc.setTextColor(100, 116, 139);
    doc.text(pair[0].label, splitX + 2.2, ry + 2.8);
    doc.setFontSize(7.5);
    doc.setTextColor(15, 23, 42);
    doc.text(String(pair[0].val), splitX + 2.2, ry + 6.2);

    // Col 2
    doc.setFontSize(6);
    doc.setTextColor(100, 116, 139);
    doc.text(pair[1].label, metaMidX + 2.2, ry + 2.8);
    doc.setFontSize(7.5);
    doc.setTextColor(15, 23, 42);
    doc.text(String(pair[1].val), metaMidX + 2.2, ry + 6.2);
  });

  y += headerH;

  // =========================================================================
  // 3. RECEIVER (BILLED TO) & CONSIGNEE (SHIPPED TO)
  // =========================================================================
  const partyH = 31;
  const partyMidX = margin + contentW / 2;

  // Sub-header bar fill FIRST
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentW, 5.8, 'F');

  // Borders AFTER fill
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.35);
  doc.line(margin, y, margin + contentW, y);
  doc.line(margin, y + 5.8, margin + contentW, y + 5.8);
  doc.line(partyMidX, y, partyMidX, y + partyH);
  doc.line(margin, y + partyH, margin + contentW, y + partyH);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.8);
  doc.setTextColor(30, 41, 59);
  doc.text('DETAILS OF RECEIVER | BILLED TO:', margin + 2.5, y + 4);
  doc.text(`State Code: ${invoice.stateCode}`, partyMidX - 2.5, y + 4, { align: 'right' });

  doc.text('DETAILS OF CONSIGNEE | SHIPPED TO:', partyMidX + 2.5, y + 4);
  doc.text(`State Code: ${invoice.stateCode}`, margin + contentW - 2.5, y + 4, { align: 'right' });

  // Billed To Body
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text(invoice.customerName.toUpperCase(), margin + 2.5, y + 10);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.2);
  doc.setTextColor(51, 65, 85);
  const billAddr = doc.splitTextToSize(invoice.customerAddress.toUpperCase(), 90).slice(0, 2);
  doc.text(billAddr, margin + 2.5, y + 14);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(
    `State: ${invoice.stateCode === '27' ? 'MAHARASHTRA' : 'OUTSIDE MAHARASHTRA'}`,
    margin + 2.5,
    y + 21.5
  );
  doc.text(`GSTIN / UIN: ${invoice.customerGstin}`, margin + 2.5, y + 25.2);
  doc.setFont('helvetica', 'normal');
  doc.text(
    `Contact: ${invoice.customerContact || '9822000000'}   |   PAN: ${customerPan}`,
    margin + 2.5,
    y + 28.8
  );

  // Shipped To Body
  const shipName = (invoice.consigneeName || invoice.customerName).toUpperCase();
  const shipAddress = (invoice.consigneeAddress || invoice.customerAddress).toUpperCase();
  const shipGstin = invoice.consigneeGstin || invoice.customerGstin;
  const shipContact = invoice.consigneeContact || invoice.customerContact || '9822000000';

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text(shipName, partyMidX + 2.5, y + 10);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.2);
  doc.setTextColor(51, 65, 85);
  const shipAddrLines = doc.splitTextToSize(shipAddress, 90).slice(0, 2);
  doc.text(shipAddrLines, partyMidX + 2.5, y + 14);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(
    `State: ${invoice.stateCode === '27' ? 'MAHARASHTRA' : 'OUTSIDE MAHARASHTRA'}`,
    partyMidX + 2.5,
    y + 21.5
  );
  doc.text(`GSTIN / UIN: ${shipGstin}`, partyMidX + 2.5, y + 25.2);
  doc.setFont('helvetica', 'normal');
  doc.text(`Contact: ${shipContact}`, partyMidX + 2.5, y + 28.8);

  y += partyH;

  // =========================================================================
  // 4. 10-COLUMN ITEMIZED GST TABLE
  // =========================================================================
  const colWidths = [8, 56, 16, 14, 12, 16, 18, 17, 17, 16];
  const colX: number[] = [margin];
  for (let i = 0; i < colWidths.length; i++) {
    colX.push(colX[i] + colWidths[i]);
  }

  const thH = 9;
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentW, thH, 'F');

  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.35);
  doc.line(margin, y, margin + contentW, y);
  doc.line(margin, y + thH, margin + contentW, y + thH);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.8);
  doc.setTextColor(15, 23, 42);

  const headers = [
    'Sr.',
    'Description of Goods / Job Work',
    'HSN/SAC',
    'Qty',
    'Unit',
    'Rate (Rs.)',
    'Taxable Amt',
    'CGST\nRate / Amt',
    'SGST\nRate / Amt',
    'Total (Rs.)',
  ];

  headers.forEach((h, idx) => {
    const cx = colX[idx];
    const cw = colWidths[idx];
    if (idx > 0) {
      doc.line(cx, y, cx, y + thH);
    }
    if (h.includes('\n')) {
      const parts = h.split('\n');
      doc.text(parts[0], cx + cw - 1.5, y + 3.8, { align: 'right' });
      doc.setFontSize(5.8);
      doc.text(parts[1], cx + cw - 1.5, y + 7.2, { align: 'right' });
      doc.setFontSize(6.8);
    } else if (idx === 0 || idx === 2 || idx === 4) {
      doc.text(h, cx + cw / 2, y + 5.5, { align: 'center' });
    } else if (idx === 1) {
      doc.text(h, cx + 2, y + 5.5);
    } else {
      doc.text(h, cx + cw - 1.5, y + 5.5, { align: 'right' });
    }
  });

  y += thH;

  // Table Body Height = 84.5mm
  const tableBodyH = 84.5;
  const tableBottomY = y + tableBodyH;

  // Draw vertical column lines through body
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.35);
  for (let i = 1; i < colWidths.length; i++) {
    doc.line(colX[i], y, colX[i], tableBottomY);
  }

  let rowY = y;
  invoice.items.forEach((item, idx) => {
    const itemTaxable = Number(item.amount) || 0;
    const isGstYes = item.gstApplicable !== false;
    const halfRate = isGstYes ? item.halfGstRate || invoice.halfGstRate || 9 : 0;
    const fullRate = halfRate * 2;
    const itemCgst =
      invoice.stateCode === '27'
        ? Number((itemTaxable * (halfRate / 100)).toFixed(2))
        : 0;
    const itemSgst =
      invoice.stateCode === '27'
        ? Number((itemTaxable * (halfRate / 100)).toFixed(2))
        : Number((itemTaxable * (fullRate / 100)).toFixed(2));
    const itemTotal = Number((itemTaxable + itemCgst + itemSgst).toFixed(2));

    const descLines = doc.splitTextToSize(item.serviceName.toUpperCase(), colWidths[1] - 3.5);
    const rowH = Math.max(8.5, descLines.length * 4 + 3);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.2);
    doc.setTextColor(15, 23, 42);

    // Sr
    doc.text(String(idx + 1), colX[0] + colWidths[0] / 2, rowY + 5, { align: 'center' });

    // Description
    doc.setFont('helvetica', 'bold');
    doc.text(descLines, colX[1] + 1.8, rowY + 4.8);

    // HSN/SAC
    doc.setFont('helvetica', 'normal');
    doc.text(item.sacCode || '998898', colX[2] + colWidths[2] / 2, rowY + 5, {
      align: 'center',
    });

    // Qty
    doc.setFont('helvetica', 'bold');
    doc.text(Number(item.qty).toFixed(2), colX[3] + colWidths[3] - 1.5, rowY + 5, {
      align: 'right',
    });

    // Unit
    doc.setFont('helvetica', 'normal');
    doc.text(String(item.unit).toUpperCase(), colX[4] + colWidths[4] / 2, rowY + 5, {
      align: 'center',
    });

    // Rate
    doc.text(Number(item.rate).toFixed(2), colX[5] + colWidths[5] - 1.5, rowY + 5, {
      align: 'right',
    });

    // Taxable
    doc.setFont('helvetica', 'bold');
    doc.text(itemTaxable.toFixed(2), colX[6] + colWidths[6] - 1.5, rowY + 5, {
      align: 'right',
    });

    // CGST
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.text(
      invoice.stateCode === '27' ? `${halfRate}% / ${itemCgst.toFixed(2)}` : '0% / 0.00',
      colX[7] + colWidths[7] - 1.2,
      rowY + 5,
      { align: 'right' }
    );

    // SGST
    doc.text(
      invoice.stateCode === '27'
        ? `${halfRate}% / ${itemSgst.toFixed(2)}`
        : `${fullRate}% / ${itemSgst.toFixed(2)}`,
      colX[8] + colWidths[8] - 1.2,
      rowY + 5,
      { align: 'right' }
    );

    // Total
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.2);
    doc.text(itemTotal.toFixed(2), colX[9] + colWidths[9] - 1.5, rowY + 5, {
      align: 'right',
    });

    rowY += rowH;
    if (rowY < tableBottomY) {
      doc.setDrawColor(203, 213, 225);
      doc.setLineWidth(0.25);
      doc.line(margin, rowY, margin + contentW, rowY);
      doc.setDrawColor(15, 23, 42);
      doc.setLineWidth(0.35);
    }
  });

  y = tableBottomY;

  // TOTAL Row (7.5mm) — Fill FIRST, then borders!
  const totalRowH = 7.5;
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentW, totalRowH, 'F');

  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.35);
  doc.line(margin, y, margin + contentW, y);
  doc.line(margin, y + totalRowH, margin + contentW, y + totalRowH);

  for (let i = 1; i < colWidths.length; i++) {
    doc.line(colX[i], y, colX[i], y + totalRowH);
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.text('TOTAL', colX[1] + colWidths[1] - 2, y + 5, { align: 'right' });
  doc.text(totalQty.toFixed(2), colX[3] + colWidths[3] - 1.5, y + 5, { align: 'right' });
  doc.text(invoice.taxableAmount.toFixed(2), colX[6] + colWidths[6] - 1.5, y + 5, {
    align: 'right',
  });
  doc.text(invoice.cgstAmount.toFixed(2), colX[7] + colWidths[7] - 1.5, y + 5, {
    align: 'right',
  });
  doc.text(
    (invoice.stateCode === '27' ? invoice.sgstAmount : invoice.igstAmount).toFixed(2),
    colX[8] + colWidths[8] - 1.5,
    y + 5,
    { align: 'right' }
  );
  doc.text(exactTotalBeforeRound.toFixed(2), colX[9] + colWidths[9] - 1.5, y + 5, {
    align: 'right',
  });

  y += totalRowH;

  // =========================================================================
  // 5. AMOUNT IN WORDS + BANK DETAILS (Left 112mm) & SUMMARY + GRAND TOTAL (Right 78mm)
  // =========================================================================
  const summaryH = 44;
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.35);
  doc.line(splitX, y, splitX, y + summaryH);
  doc.line(margin, y + summaryH, margin + contentW, y + summaryH);

  // Left: Amount in Words
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.text('AMOUNT CHARGEABLE (IN WORDS):', margin + 3, y + 5);

  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  const wordsLines = doc.splitTextToSize(
    numberToIndianRupeesWords(invoice.grandTotal).toUpperCase(),
    106
  );
  doc.text(wordsLines, margin + 3, y + 9.5);

  // Bank Details Sub-Box inside Left Column
  const bankTopY = y + 16.5;
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, bankTopY, 112, 5.8, 'F');
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.3);
  doc.line(margin, bankTopY, splitX, bankTopY);
  doc.line(margin, bankTopY + 5.8, splitX, bankTopY + 5.8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.8);
  doc.setTextColor(30, 41, 59);
  doc.text("COMPANY'S BANK DETAILS FOR RTGS / NEFT", margin + 3, bankTopY + 4);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.text(`Bank Name: ${companyInfo.bankName}`, margin + 3, bankTopY + 10);
  doc.text(`Branch: ${companyInfo.branchName}`, margin + 60, bankTopY + 10);
  doc.setFont('helvetica', 'bold');
  doc.text(`A/C No.: ${companyInfo.accountNo}`, margin + 3, bankTopY + 15);
  doc.text(`IFSC Code: ${companyInfo.ifsc}`, margin + 60, bankTopY + 15);

  // Right: Tax Summary Breakdown
  let sumY = y + 5.5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(51, 65, 85);

  doc.text('Taxable Subtotal:', splitX + 3, sumY);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(invoice.taxableAmount.toFixed(2), margin + contentW - 3, sumY, { align: 'right' });

  sumY += 5.5;
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);
  doc.text('Central GST (CGST):', splitX + 3, sumY);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(invoice.cgstAmount.toFixed(2), margin + contentW - 3, sumY, { align: 'right' });

  sumY += 5.5;
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);
  doc.text(
    invoice.stateCode === '27' ? 'State GST (SGST):' : 'Integrated GST (IGST):',
    splitX + 3,
    sumY
  );
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(
    (invoice.stateCode === '27' ? invoice.sgstAmount : invoice.igstAmount).toFixed(2),
    margin + contentW - 3,
    sumY,
    { align: 'right' }
  );

  sumY += 5.5;
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);
  doc.text('Round Off:', splitX + 3, sumY);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  const roundStr =
    invoice.roundOff >= 0
      ? `+${invoice.roundOff.toFixed(2)}`
      : invoice.roundOff.toFixed(2);
  doc.text(roundStr, margin + contentW - 3, sumY, { align: 'right' });

  // Dark Navy GRAND TOTAL Box
  doc.setFillColor(15, 23, 42);
  doc.rect(splitX + 2.5, y + summaryH - 14.5, 73, 12, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8.5);
  doc.text('GRAND TOTAL:', splitX + 5.5, y + summaryH - 8.5);
  doc.setFontSize(6);
  doc.setTextColor(203, 213, 225);
  doc.text('(Total Invoice Value)', splitX + 5.5, y + summaryH - 4.8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(255, 255, 255);
  doc.text(
    `Rs. ${invoice.grandTotal.toLocaleString('en-IN', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`,
    margin + contentW - 4.5,
    y + summaryH - 6.8,
    { align: 'right' }
  );

  y += summaryH;

  // =========================================================================
  // 6. TERMS & SIGNATURES FOOTER
  // =========================================================================
  const footerH = topY + totalBoxH - y;
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.35);
  doc.line(splitX, y, splitX, y + footerH);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.5);
  doc.setTextColor(30, 41, 59);
  doc.text('DECLARATION & TERMS:', margin + 3, y + 5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.2);
  doc.setTextColor(51, 65, 85);
  doc.text(
    '1. We declare that this invoice shows the actual price of the goods/job work described and that all particulars are true and correct.',
    margin + 3,
    y + 9.5,
    { maxWidth: 106 }
  );
  doc.text(
    '2. Interest @ 18% p.a. will be charged if payment is not made within the stipulated due date.',
    margin + 3,
    y + 15.5
  );
  doc.text('3. Subject to Pune Jurisdiction only.', margin + 3, y + 19.5);

  // Signatures
  const sigMidX = splitX + 39;
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.35);
  doc.line(sigMidX, y, sigMidX, y + footerH);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.5);
  doc.setTextColor(51, 65, 85);
  doc.text("Receiver's Signature & Seal", splitX + 19.5, y + footerH - 4, {
    align: 'center',
  });

  doc.setFontSize(6.8);
  doc.setTextColor(15, 23, 42);
  doc.text(`For ${companyInfo.name.toUpperCase()}`, sigMidX + 19.5, y + 5, {
    align: 'center',
  });
  doc.setFontSize(6.5);
  doc.setTextColor(51, 65, 85);
  doc.text('Authorised Signatory', sigMidX + 19.5, y + footerH - 4, {
    align: 'center',
  });

  // =========================================================================
  // 7. MASTER OUTER BORDER (Drawn LAST so all 4 outer sides are 100% solid & unbroken)
  // =========================================================================
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.6);
  doc.rect(margin, topY, contentW, totalBoxH, 'S');

  doc.save(`Tax_Invoice_${invoice.invoiceNo}.pdf`);
}
