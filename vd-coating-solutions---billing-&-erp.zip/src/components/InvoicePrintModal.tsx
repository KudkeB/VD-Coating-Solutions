import React, { useState } from 'react';
import {
  Printer,
  ArrowLeft,
  ZoomIn,
  ZoomOut,
  Copy,
  FileDown,
  ReceiptIndianRupee,
  Pencil,
} from 'lucide-react';
import {
  Invoice,
  COMPANY_PROFILE,
  CompanyProfileConfig,
  numberToIndianRupeesWords,
  extractPanFromGstin,
  formatDateDDMMYYYY,
} from '../data/vdCoatingData';
import { downloadInvoicePdf } from '../utils/invoicePdfGenerator';
import { VdLogo } from './VdLogo';

interface InvoicePrintModalProps {
  invoice: Invoice | null;
  companyInfo?: CompanyProfileConfig;
  onClose: () => void;
  onToggleStatus?: (invoiceId: string) => void;
  onDuplicateInvoice?: (invoice: Invoice) => void;
  onEditInvoice?: (invoice: Invoice) => void;
}

type CopyType = 'ORIGINAL FOR RECIPIENT' | 'DUPLICATE FOR TRANSPORTER' | 'TRIPLICATE FOR SUPPLIER';

export const InvoicePrintModal: React.FC<InvoicePrintModalProps> = ({
  invoice,
  companyInfo = COMPANY_PROFILE,
  onClose,
  onToggleStatus,
  onDuplicateInvoice,
  onEditInvoice,
}) => {
  const [zoom, setZoom] = useState<number>(100);
  const [copyType, setCopyType] = useState<CopyType>('ORIGINAL FOR RECIPIENT');

  if (!invoice) return null;

  const handlePrint = () => {
    window.focus();
    window.print();
  };

  const handleDownloadPdf = () => {
    downloadInvoicePdf(invoice, companyInfo, copyType);
  };

  const totalQty = invoice.items.reduce((sum, item) => sum + (Number(item.qty) || 0), 0);
  const exactTotalBeforeRound = Number((invoice.taxableAmount + invoice.totalGst).toFixed(2));
  const customerPan = invoice.customerPan || extractPanFromGstin(invoice.customerGstin);
  const minBlankRows = Math.max(0, 7 - invoice.items.length);

  const zoomPresets = [100, 115, 125, 135, 150];

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-gray-200 text-slate-900 overflow-y-auto print:static print:bg-white">
      {/* ====================================================================
          TOP INVOICE WORKSPACE TOOLBAR
         ==================================================================== */}
      <div className="no-print sticky top-0 z-30 bg-gray-100 border-b border-gray-300 px-4 sm:px-6 py-3 shadow-sm">
        <div className="max-w-6xl mx-auto space-y-3">
          {/* Row 1: Back to Invoices + Invoice Title + Status Badge */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button
                onClick={onClose}
                className="px-3.5 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 text-slate-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back to Invoices
              </button>
              <div className="h-6 w-px bg-gray-300 hidden sm:block"></div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-extrabold text-slate-900">
                    Invoice {invoice.invoiceNo}
                  </h2>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                      invoice.status === 'PAID'
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {invoice.status === 'PAID' ? 'Paid' : 'Pending'}
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  Dated: {formatDateDDMMYYYY(invoice.date)}
                </p>
              </div>
            </div>

            {/* Right Action Buttons: + Receipt, Edit */}
            <div className="flex flex-wrap items-center gap-2">
              {onToggleStatus && (
                <button
                  onClick={() => onToggleStatus(invoice.id)}
                  className="px-3.5 py-2 rounded-lg border border-emerald-500 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <ReceiptIndianRupee className="w-3.5 h-3.5" />
                  {invoice.status === 'PAID' ? 'Mark Pending' : '+ Receipt (जमा करा)'}
                </button>
              )}
              {onEditInvoice && (
                <button
                  onClick={() => onEditInvoice(invoice)}
                  className="px-3.5 py-2 rounded-lg border border-amber-400 bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Pencil className="w-3.5 h-3.5" />
                  Edit Invoice (एडिट करा)
                </button>
              )}
            </div>
          </div>

          {/* Row 2: Zoom Controls (100% - 150%) + Copy Selector (Original / Duplicate / Triplicate) + Edit / Download PDF */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-gray-300">
            <div className="flex flex-wrap items-center gap-2">
              {/* Zoom Bar */}
              <div className="flex items-center gap-1 bg-white border border-gray-300 rounded-lg p-1 text-xs">
                <button
                  onClick={() => setZoom((z) => Math.max(80, z - 10))}
                  className="p-1.5 hover:bg-gray-200 rounded text-slate-600 cursor-pointer"
                  title="Zoom Out"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <span className="px-1.5 font-mono font-bold text-blue-600">{zoom}%</span>
                <button
                  onClick={() => setZoom((z) => Math.min(150, z + 10))}
                  className="p-1.5 hover:bg-gray-200 rounded text-slate-600 cursor-pointer"
                  title="Zoom In"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
                <div className="h-4 w-px bg-gray-300 mx-1 hidden sm:block"></div>
                <div className="hidden sm:flex items-center gap-1">
                  {zoomPresets.map((preset) => (
                    <button
                      key={preset}
                      onClick={() => setZoom(preset)}
                      className={`px-2 py-1 rounded text-[11px] font-semibold transition-colors cursor-pointer ${
                        zoom === preset
                          ? 'bg-blue-600 text-white'
                          : 'text-slate-600 hover:bg-gray-200'
                      }`}
                    >
                      {preset}%
                    </button>
                  ))}
                </div>
              </div>

              {/* Copy Type Selector: Original / Duplicate / Triplicate */}
              <div className="flex items-center gap-1 bg-white border border-gray-300 rounded-lg p-1 text-xs">
                {(
                  [
                    { label: 'Original - Recipient', val: 'ORIGINAL FOR RECIPIENT' },
                    { label: 'Duplicate - Transporter', val: 'DUPLICATE FOR TRANSPORTER' },
                    { label: 'Triplicate - Supplier', val: 'TRIPLICATE FOR SUPPLIER' },
                  ] as const
                ).map((c) => (
                  <button
                    key={c.val}
                    onClick={() => setCopyType(c.val)}
                    className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors cursor-pointer ${
                      copyType === c.val
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {c.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Duplicate, Edit Invoice, Download PDF */}
            <div className="flex flex-wrap items-center gap-2">
              {onDuplicateInvoice && (
                <button
                  onClick={() => onDuplicateInvoice(invoice)}
                  className="px-3.5 py-2 rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  Duplicate
                </button>
              )}
              {onEditInvoice && (
                <button
                  onClick={() => onEditInvoice(invoice)}
                  className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                >
                  <Pencil className="w-3.5 h-3.5" />
                  Edit Invoice
                </button>
              )}
              <button
                onClick={handleDownloadPdf}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
              >
                <FileDown className="w-3.5 h-3.5" />
                Download PDF
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ====================================================================
          EXACT A4 PRINTABLE TAX INVOICE SHEET (MATCHING UPLOADED PDF)
         ==================================================================== */}
      <div className="flex-1 p-2 sm:p-6 overflow-x-auto flex justify-center print:p-0 print:block">
        <div
          style={{
            width: `${Math.round(860 * (zoom / 100))}px`,
          }}
          className="bg-white text-[#0f172a] shadow-xl border border-slate-300 p-4 sm:p-7 print-sheet transition-all print:w-full print:shadow-none print:border-none print:p-0"
        >
          {/* Outer Dark Slate / Black Border */}
          <div className="border-2 border-slate-900 bg-white text-[11px] leading-snug">
            {/* 1. TOP HEADER BAR */}
            <div className="grid grid-cols-3 items-center px-3 py-2 bg-slate-100 border-b-[1.5px] border-slate-900">
              <div className="text-[10px] font-bold tracking-wide text-slate-700">
                GST TAX INVOICE (RULE 46 OF CGST RULES)
              </div>
              <div className="text-center text-base font-extrabold tracking-wider text-slate-900">
                TAX INVOICE
              </div>
              <div className="flex justify-end">
                <span className="bg-[#0f172a] text-white text-[9.5px] font-bold tracking-wider uppercase px-3 py-1 rounded">
                  {copyType}
                </span>
              </div>
            </div>

            {/* 2. COMPANY DETAILS (LEFT 58%) & INVOICE METADATA GRID (RIGHT 42%) */}
            <div className="grid grid-cols-12 border-b-[1.5px] border-slate-900">
              {/* Left: Logo Box + Company Details */}
              <div className="col-span-12 md:col-span-7 p-3.5 md:border-r-[1.5px] border-slate-900 flex items-start gap-3.5">
                {/* Styled Industrial Coating Emblem Box or Custom Uploaded Logo */}
                <VdLogo
                  size="xl"
                  logoUrl={companyInfo.logoUrl}
                  className="border-[1.5px] border-slate-900 rounded-md p-0.5 shadow-none"
                />

                {/* Company Text Info */}
                <div className="space-y-0.5 text-[11px] flex-1 min-w-0">
                  <h1 className="text-lg font-extrabold tracking-tight text-slate-900 uppercase leading-tight">
                    {companyInfo.name}
                  </h1>
                  <p className="text-[10px] text-slate-700 font-bold uppercase">
                    {companyInfo.tagline}
                  </p>
                  <p className="text-[10.5px] text-slate-800 font-semibold leading-snug pt-0.5">
                    {companyInfo.address}
                  </p>
                  <p className="text-[10.5px] font-bold text-slate-900 pt-0.5">
                    State: {companyInfo.state || 'Maharashtra'} <span className="mx-1">|</span> State Code: {companyInfo.stateCode || '27'}
                  </p>
                  <p className="text-[10.5px] font-bold text-slate-900">
                    GSTIN: <span className="font-mono">{companyInfo.gstin}</span>
                    <span className="mx-2 text-slate-400">|</span>
                    PAN: <span className="font-mono">{companyInfo.pan}</span>
                  </p>
                  <p className="text-[10px] font-bold text-slate-800 break-words">
                    Mobile: {companyInfo.phone}
                  </p>
                  <p className="text-[10px] font-bold text-slate-800 break-all">
                    Email: {companyInfo.email}
                  </p>
                </div>
              </div>

              {/* Right: 5x2 Invoice Metadata Grid */}
              <div className="col-span-12 md:col-span-5 grid grid-cols-2 divide-y divide-slate-800 text-[10.5px]">
                {/* Row 1 */}
                <div className="px-3 py-1.5 border-r border-slate-800 bg-slate-50/50">
                  <span className="block text-[9px] font-bold text-slate-600 uppercase">
                    INVOICE NO:
                  </span>
                  <span className="font-extrabold text-slate-900 text-sm font-mono">
                    {invoice.invoiceNo}
                  </span>
                </div>
                <div className="px-3 py-1.5 bg-slate-50/50">
                  <span className="block text-[9px] font-bold text-slate-600 uppercase">
                    DATED:
                  </span>
                  <span className="font-extrabold text-slate-900 text-xs font-mono">
                    {formatDateDDMMYYYY(invoice.date)}
                  </span>
                </div>

                {/* Row 2 */}
                <div className="px-3 py-1.5 border-r border-slate-800">
                  <span className="block text-[9px] font-bold text-slate-600 uppercase">
                    CHALLAN NO:
                  </span>
                  <span className="font-bold text-slate-900 font-mono">
                    {invoice.challanNo || '-'}
                  </span>
                </div>
                <div className="px-3 py-1.5">
                  <span className="block text-[9px] font-bold text-slate-600 uppercase">
                    CHALLAN DATE:
                  </span>
                  <span className="font-bold text-slate-900 font-mono">
                    {formatDateDDMMYYYY(invoice.challanDate || invoice.date)}
                  </span>
                </div>

                {/* Row 3 */}
                <div className="px-3 py-1.5 border-r border-slate-800">
                  <span className="block text-[9px] font-bold text-slate-600 uppercase">
                    P.O. NUMBER:
                  </span>
                  <span className="font-bold text-slate-900 font-mono">
                    {invoice.poNumber || '-'}
                  </span>
                </div>
                <div className="px-3 py-1.5">
                  <span className="block text-[9px] font-bold text-slate-600 uppercase">
                    P.O. DATE:
                  </span>
                  <span className="font-bold text-slate-900 font-mono">
                    {invoice.poDate && invoice.poDate !== '-'
                      ? formatDateDDMMYYYY(invoice.poDate)
                      : '-'}
                  </span>
                </div>

                {/* Row 4 */}
                <div className="px-3 py-1.5 border-r border-slate-800">
                  <span className="block text-[9px] font-bold text-slate-600 uppercase">
                    PLACE OF SUPPLY:
                  </span>
                  <span className="font-bold text-slate-900 uppercase">
                    {invoice.stateCode === '27' ? 'MAHARASHTRA (27)' : `STATE (${invoice.stateCode})`}
                  </span>
                </div>
                <div className="px-3 py-1.5">
                  <span className="block text-[9px] font-bold text-slate-600 uppercase">
                    REVERSE CHARGE:
                  </span>
                  <span className="font-bold text-slate-900">
                    {invoice.reverseCharge || 'NO'}
                  </span>
                </div>

                {/* Row 5 */}
                <div className="px-3 py-1.5 border-r border-slate-800">
                  <span className="block text-[9px] font-bold text-slate-600 uppercase">
                    VEHICLE NO:
                  </span>
                  <span className="font-bold text-slate-900 font-mono">
                    {invoice.vehicleNo || '-'}
                  </span>
                </div>
                <div className="px-3 py-1.5">
                  <span className="block text-[9px] font-bold text-slate-600 uppercase">
                    TRANSPORT:
                  </span>
                  <span className="font-bold text-slate-900">
                    {invoice.transportMode || 'Road / Tempo'}
                  </span>
                </div>
              </div>
            </div>

            {/* 3. RECEIVER (BILLED TO) & CONSIGNEE (SHIPPED TO) SECTION */}
            <div className="grid grid-cols-12 border-b-[1.5px] border-slate-900">
              {/* Left: Details of Receiver | Billed To */}
              <div className="col-span-12 md:col-span-6 md:border-r-[1.5px] border-slate-900">
                <div className="flex items-center justify-between px-3 py-1 bg-slate-100 border-b border-slate-800 text-[9.5px] font-bold text-slate-800 uppercase">
                  <span>DETAILS OF RECEIVER | BILLED TO:</span>
                  <span>State Code: {invoice.stateCode}</span>
                </div>
                <div className="p-3 space-y-0.5 text-[10.5px]">
                  <div className="text-xs font-extrabold text-slate-900 uppercase">
                    {invoice.customerName}
                  </div>
                  <div className="text-slate-700 uppercase leading-snug">
                    {invoice.customerAddress}
                  </div>
                  <div className="pt-1 font-bold text-slate-900">
                    State: {invoice.stateCode === '27' ? 'MAHARASHTRA' : 'OUTSIDE MAHARASHTRA'}
                  </div>
                  <div className="font-bold text-slate-900">
                    GSTIN / UIN: <span className="font-mono">{invoice.customerGstin}</span>
                  </div>
                  <div className="text-slate-700">
                    Contact: <span className="font-mono">{invoice.customerContact || '9822000000'}</span>
                    <span className="mx-2 text-slate-400">|</span>
                    PAN: <span className="font-mono">{customerPan}</span>
                  </div>
                </div>
              </div>

              {/* Right: Details of Consignee | Shipped To */}
              <div className="col-span-12 md:col-span-6">
                <div className="flex items-center justify-between px-3 py-1 bg-slate-100 border-b border-slate-800 text-[9.5px] font-bold text-slate-800 uppercase">
                  <span>DETAILS OF CONSIGNEE | SHIPPED TO:</span>
                  <span>State Code: {invoice.stateCode}</span>
                </div>
                <div className="p-3 space-y-0.5 text-[10.5px]">
                  <div className="text-xs font-extrabold text-slate-900 uppercase">
                    {invoice.consigneeName || invoice.customerName}
                  </div>
                  <div className="text-slate-700 uppercase leading-snug">
                    {invoice.consigneeAddress || invoice.customerAddress}
                  </div>
                  <div className="pt-1 font-bold text-slate-900">
                    State: {invoice.stateCode === '27' ? 'MAHARASHTRA' : 'OUTSIDE MAHARASHTRA'}
                  </div>
                  <div className="font-bold text-slate-900">
                    GSTIN / UIN:{' '}
                    <span className="font-mono">
                      {invoice.consigneeGstin || invoice.customerGstin}
                    </span>
                  </div>
                  <div className="text-slate-700">
                    Contact:{' '}
                    <span className="font-mono">
                      {invoice.consigneeContact || invoice.customerContact || '9822000000'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* 4. 10-COLUMN ITEMIZED GST TABLE */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-[10.5px]">
                <thead>
                  <tr className="bg-slate-100 border-b-[1.5px] border-slate-900 text-slate-900 font-bold">
                    <th className="py-2 px-2 border-r border-slate-800 w-9 text-center">Sr.</th>
                    <th className="py-2 px-2.5 border-r border-slate-800 text-left">
                      Description of Goods / Job Work
                    </th>
                    <th className="py-2 px-2 border-r border-slate-800 w-16 text-center">
                      HSN/SAC
                    </th>
                    <th className="py-2 px-2 border-r border-slate-800 w-14 text-right">Qty</th>
                    <th className="py-2 px-1.5 border-r border-slate-800 w-12 text-center">
                      Unit
                    </th>
                    <th className="py-2 px-2 border-r border-slate-800 w-16 text-right">
                      Rate (Rs.)
                    </th>
                    <th className="py-2 px-2 border-r border-slate-800 w-20 text-right">
                      Taxable Amt
                    </th>
                    <th className="py-1.5 px-2 border-r border-slate-800 w-20 text-right leading-tight">
                      <div>CGST</div>
                      <div className="text-[9px] font-medium text-slate-600">Rate / Amt</div>
                    </th>
                    <th className="py-1.5 px-2 border-r border-slate-800 w-20 text-right leading-tight">
                      <div>SGST</div>
                      <div className="text-[9px] font-medium text-slate-600">Rate / Amt</div>
                    </th>
                    <th className="py-2 px-2.5 w-20 text-right">Total (Rs.)</th>
                  </tr>
                </thead>
                <tbody>
                  {invoice.items.map((item, idx) => {
                    const itemTaxable = Number(item.amount) || 0;
                    const isGstYes = item.gstApplicable !== false;
                    const halfRate = isGstYes
                      ? item.halfGstRate || invoice.halfGstRate || 9
                      : 0;
                    const fullRate = halfRate * 2;
                    const itemCgst =
                      invoice.stateCode === '27'
                        ? Number((itemTaxable * (halfRate / 100)).toFixed(2))
                        : 0;
                    const itemSgst =
                      invoice.stateCode === '27'
                        ? Number((itemTaxable * (halfRate / 100)).toFixed(2))
                        : Number((itemTaxable * (fullRate / 100)).toFixed(2));
                    const itemTotal = Number((itemTaxable + itemCgst + itemSgst).toFixed(2));

                    return (
                      <tr key={item.id} className="border-b border-slate-300 align-top">
                        <td className="py-2.5 px-2 border-r border-slate-800 text-center font-mono">
                          {idx + 1}
                        </td>
                        <td className="py-2.5 px-2.5 border-r border-slate-800">
                          <div className="font-bold text-slate-900 uppercase">
                            {item.serviceName}
                          </div>
                          {item.partSpecification &&
                            item.partSpecification.trim().toUpperCase() !==
                              item.serviceName.trim().toUpperCase() && (
                              <div className="text-[9.5px] text-slate-600 mt-0.5">
                                {item.partSpecification}
                              </div>
                            )}
                        </td>
                        <td className="py-2.5 px-2 border-r border-slate-800 text-center font-mono text-slate-700">
                          {item.sacCode || '998898'}
                        </td>
                        <td className="py-2.5 px-2 border-r border-slate-800 text-right font-mono font-semibold text-slate-900">
                          {Number(item.qty).toFixed(2)}
                        </td>
                        <td className="py-2.5 px-1.5 border-r border-slate-800 text-center font-mono uppercase text-slate-700">
                          {item.unit}
                        </td>
                        <td className="py-2.5 px-2 border-r border-slate-800 text-right font-mono text-slate-900">
                          {Number(item.rate).toFixed(2)}
                        </td>
                        <td className="py-2.5 px-2 border-r border-slate-800 text-right font-mono font-semibold text-slate-900">
                          {itemTaxable.toFixed(2)}
                        </td>
                        <td className="py-2.5 px-2 border-r border-slate-800 text-right font-mono text-slate-700 whitespace-nowrap">
                          {invoice.stateCode === '27'
                            ? `${halfRate}% / ${itemCgst.toFixed(2)}`
                            : `0% / 0.00`}
                        </td>
                        <td className="py-2.5 px-2 border-r border-slate-800 text-right font-mono text-slate-700 whitespace-nowrap">
                          {invoice.stateCode === '27'
                            ? `${halfRate}% / ${itemSgst.toFixed(2)}`
                            : `${fullRate}% / ${itemSgst.toFixed(2)}`}
                        </td>
                        <td className="py-2.5 px-2.5 text-right font-mono font-bold text-slate-900">
                          {itemTotal.toFixed(2)}
                        </td>
                      </tr>
                    );
                  })}

                  {/* Vertical filler rows to match tall A4 table sheet */}
                  {Array.from({ length: minBlankRows }).map((_, idx) => (
                    <tr key={`blank-${idx}`} className="h-9">
                      <td className="border-r border-slate-800"></td>
                      <td className="border-r border-slate-800"></td>
                      <td className="border-r border-slate-800"></td>
                      <td className="border-r border-slate-800"></td>
                      <td className="border-r border-slate-800"></td>
                      <td className="border-r border-slate-800"></td>
                      <td className="border-r border-slate-800"></td>
                      <td className="border-r border-slate-800"></td>
                      <td className="border-r border-slate-800"></td>
                      <td></td>
                    </tr>
                  ))}
                </tbody>

                {/* Table Footer TOTAL Row */}
                <tfoot>
                  <tr className="bg-slate-100 border-t-[1.5px] border-b-[1.5px] border-slate-900 font-extrabold text-slate-900">
                    <td className="py-2 px-2 border-r border-slate-800"></td>
                    <td className="py-2 px-2.5 border-r border-slate-800 text-right uppercase tracking-wide">
                      TOTAL
                    </td>
                    <td className="py-2 px-2 border-r border-slate-800"></td>
                    <td className="py-2 px-2 border-r border-slate-800 text-right font-mono">
                      {totalQty.toFixed(2)}
                    </td>
                    <td className="py-2 px-1.5 border-r border-slate-800"></td>
                    <td className="py-2 px-2 border-r border-slate-800"></td>
                    <td className="py-2 px-2 border-r border-slate-800 text-right font-mono">
                      {invoice.taxableAmount.toFixed(2)}
                    </td>
                    <td className="py-2 px-2 border-r border-slate-800 text-right font-mono">
                      {invoice.cgstAmount.toFixed(2)}
                    </td>
                    <td className="py-2 px-2 border-r border-slate-800 text-right font-mono">
                      {(invoice.stateCode === '27'
                        ? invoice.sgstAmount
                        : invoice.igstAmount
                      ).toFixed(2)}
                    </td>
                    <td className="py-2 px-2.5 text-right font-mono">
                      {exactTotalBeforeRound.toFixed(2)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* 5. AMOUNT IN WORDS + BANK DETAILS (LEFT 7 COLS) & GRAND TOTAL BOX (RIGHT 5 COLS) */}
            <div className="grid grid-cols-12 border-b-[1.5px] border-slate-900">
              {/* Left 7 Cols: Amount Chargeable in Words + Bank Details */}
              <div className="col-span-12 md:col-span-7 md:border-r-[1.5px] border-slate-900 p-3 space-y-3">
                <div>
                  <div className="text-[9.5px] font-bold uppercase text-slate-500">
                    AMOUNT CHARGEABLE (IN WORDS):
                  </div>
                  <div className="text-xs font-extrabold text-slate-900 mt-0.5">
                    {numberToIndianRupeesWords(invoice.grandTotal)}
                  </div>
                </div>

                <div className="border-t border-slate-800 pt-2">
                  <div className="bg-slate-100 px-2.5 py-1 text-[9.5px] font-bold uppercase text-slate-800 border border-slate-800 mb-2">
                    COMPANY&apos;S BANK DETAILS FOR RTGS / NEFT
                  </div>
                  <div className="grid grid-cols-2 gap-1 text-[10.5px] px-1">
                    <div>
                      <span className="text-slate-600">Bank Name:</span>{' '}
                      <strong className="text-slate-900">{companyInfo.bankName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-600">Branch:</span>{' '}
                      <strong className="text-slate-900">{companyInfo.branchName}</strong>
                    </div>
                    <div className="col-span-2 font-bold text-slate-900 font-mono">
                      A/C No: {companyInfo.accountNo}
                    </div>
                    <div className="col-span-2 font-bold text-slate-900 font-mono">
                      IFSC Code: {companyInfo.ifsc}
                    </div>
                  </div>
                </div>
              </div>

              {/* Right 5 Cols: Subtotal, CGST, SGST, Round Off, Dark Navy GRAND TOTAL Box */}
              <div className="col-span-12 md:col-span-5 p-3 flex flex-col justify-between space-y-2">
                <div className="space-y-1.5 text-[11px]">
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span className="text-slate-600 font-medium">Taxable Subtotal:</span>
                    <span className="font-mono font-bold text-slate-900">
                      {invoice.taxableAmount.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span className="text-slate-600 font-medium">Central GST (CGST):</span>
                    <span className="font-mono font-bold text-slate-900">
                      {invoice.cgstAmount.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span className="text-slate-600 font-medium">
                      {invoice.stateCode === '27' ? 'State GST (SGST):' : 'Integrated GST (IGST):'}
                    </span>
                    <span className="font-mono font-bold text-slate-900">
                      {(invoice.stateCode === '27'
                        ? invoice.sgstAmount
                        : invoice.igstAmount
                      ).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-600 font-medium">Round Off:</span>
                    <span className="font-mono font-bold text-slate-900">
                      {invoice.roundOff >= 0
                        ? invoice.roundOff === 0
                          ? '0.00'
                          : `+${invoice.roundOff.toFixed(2)}`
                        : invoice.roundOff.toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Dark Navy Pill Box for GRAND TOTAL */}
                <div className="bg-[#0f172a] text-white rounded-md px-3.5 py-2.5 flex items-center justify-between">
                  <div>
                    <div className="text-[10.5px] font-extrabold tracking-wide uppercase">
                      GRAND TOTAL:
                    </div>
                    <div className="text-[9px] text-slate-300">(Total Invoice Value)</div>
                  </div>
                  <div className="text-base font-extrabold font-mono tracking-tight">
                    Rs. {invoice.grandTotal.toFixed(2)}
                  </div>
                </div>
              </div>
            </div>

            {/* 6. TERMS & CONDITIONS AND SIGNATURES FOOTER */}
            <div className="grid grid-cols-12 p-3.5 min-h-[125px]">
              <div className="col-span-12 md:col-span-7 flex flex-col justify-between pr-4">
                <div className="space-y-0.5 text-[9.5px] text-slate-600">
                  <div className="font-bold text-slate-800 uppercase mb-1">
                    TERMS &amp; CONDITIONS:
                  </div>
                  <p>
                    1. We declare that this invoice shows the actual price of the goods described
                    and that all particulars are true and correct.
                  </p>
                  <p>2. Goods once sold / coated will not be taken back unless agreed otherwise.</p>
                  <p>3. Payment should be made as per agreed terms.</p>
                </div>

                <div className="pt-8">
                  <span className="inline-block border-t border-slate-400 pt-1 pr-8 text-[10px] font-bold text-slate-800">
                    Receiver&apos;s Signature &amp; Seal
                  </span>
                </div>
              </div>

              <div className="col-span-12 md:col-span-5 flex flex-col justify-between items-end text-right mt-4 md:mt-0">
                <div className="text-[11px] font-extrabold text-slate-900 uppercase">
                  For {companyInfo.name}
                </div>

                <div className="pt-10">
                  <span className="inline-block border-t border-slate-400 pt-1 pl-8 text-[10px] text-slate-600 font-medium">
                    Authorised Signatory
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
