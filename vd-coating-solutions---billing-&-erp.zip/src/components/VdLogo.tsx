import React from 'react';

interface VdLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  logoUrl?: string;
}

/**
 * High-contrast 3D Metallic VD Shield + Deep Blue Orbital Swoosh + Starburst Logo
 * Matches the uploaded VD Coating Solutions emblem clearly at all sizes (App Icon, Header, Sidebar & Invoice).
 */
export const VdLogo: React.FC<VdLogoProps> = ({ className = '', size = 'md', logoUrl }) => {
  const sizeClasses = {
    sm: 'w-9 h-9',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24',
  }[size];

  if (logoUrl && logoUrl.trim() !== '') {
    return (
      <div
        className={`relative flex items-center justify-center shrink-0 bg-white rounded-xl overflow-hidden ${sizeClasses} ${className}`}
      >
        <img
          src={logoUrl}
          alt="VD Coating Solutions Logo"
          referrerPolicy="no-referrer"
          className="w-full h-full object-contain p-0.5"
        />
      </div>
    );
  }

  return (
    <div
      className={`relative flex items-center justify-center shrink-0 bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden ${sizeClasses} ${className}`}
    >
      <svg
        viewBox="0 0 240 240"
        className="w-full h-full select-none"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Background subtle radial sheen */}
          <radialGradient id="vdBgGrad" cx="50%" cy="45%" r="60%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="75%" stopColor="#F8FAFC" />
            <stop offset="100%" stopColor="#E2E8F0" />
          </radialGradient>

          {/* 3D Chrome / Metallic Light Bevel */}
          <linearGradient id="vdChromeLight" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F8FAFC" />
            <stop offset="35%" stopColor="#CBD5E1" />
            <stop offset="70%" stopColor="#64748B" />
            <stop offset="100%" stopColor="#334155" />
          </linearGradient>

          {/* 3D Metallic Dark Steel Contrast */}
          <linearGradient id="vdSteelDark" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#475569" />
            <stop offset="50%" stopColor="#1E293B" />
            <stop offset="100%" stopColor="#0F172A" />
          </linearGradient>

          {/* Deep Royal / Navy Blue Orbital Swoosh Gradient */}
          <linearGradient id="vdOrbitBlue" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#0F172A" />
            <stop offset="30%" stopColor="#1E3A8A" />
            <stop offset="65%" stopColor="#2563EB" />
            <stop offset="85%" stopColor="#60A5FA" />
            <stop offset="100%" stopColor="#1D4ED8" />
          </linearGradient>

          {/* Drop shadow for bold icon legibility */}
          <filter id="vdDropShadow" x="-15%" y="-15%" width="130%" height="130%">
            <feDropShadow dx="0" dy="3" stdDeviation="3" floodColor="#0F172A" floodOpacity="0.28" />
          </filter>
        </defs>

        {/* Clean Bright Background */}
        <rect width="240" height="240" rx="36" fill="url(#vdBgGrad)" />

        {/* Back Portion of Orbiting Blue Ring (Upper Left / Top) */}
        <path
          d="M 38 118 C 26 72, 85 28, 156 36 C 198 40, 218 68, 206 104"
          stroke="#CBD5E1"
          strokeWidth="12"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M 42 112 C 34 74, 88 34, 154 40 C 192 44, 210 68, 200 100"
          stroke="#64748B"
          strokeWidth="6"
          strokeLinecap="round"
          fill="none"
        />

        {/* 3D Metallic Shield Outer Frame */}
        <g filter="url(#vdDropShadow)">
          <path
            d="M 120 22 L 194 48 C 194 118, 172 174, 120 218 C 68 174, 46 118, 46 48 Z"
            fill="url(#vdSteelDark)"
            stroke="url(#vdChromeLight)"
            strokeWidth="6"
            strokeLinejoin="round"
          />

          {/* Shield Inner Bright Bevel Cutout */}
          <path
            d="M 120 34 L 180 56 C 180 115, 160 163, 120 202 C 80 163, 60 115, 60 56 Z"
            fill="#F8FAFC"
            stroke="#94A3B8"
            strokeWidth="3"
            strokeLinejoin="round"
          />

          {/* Bold 3D Intertwined "V" and "D" Monogram */}
          {/* V Letter - Left & Center Bold Metallic */}
          <path
            d="M 66 64 L 90 64 L 112 138 L 134 64 L 154 64 L 120 172 L 102 172 Z"
            fill="url(#vdSteelDark)"
          />
          <path
            d="M 70 67 L 87 67 L 111 146 L 103 168 L 66 64 Z"
            fill="url(#vdChromeLight)"
          />

          {/* D Letter - Interlocked Right Bold Metallic */}
          <path
            d="M 116 64 L 152 64 C 176 64, 190 82, 190 114 C 190 146, 174 166, 148 166 L 116 166 Z M 136 82 L 136 148 L 147 148 C 162 148, 170 135, 170 114 C 170 93, 162 82, 147 82 Z"
            fill="url(#vdSteelDark)"
          />
          <path
            d="M 118 66 L 150 66 C 172 66, 185 82, 185 114 C 185 142, 171 160, 148 160 L 136 148 L 147 148 C 162 148, 170 135, 170 114 C 170 93, 162 82, 147 82 L 136 82 L 136 164 L 118 164 Z"
            fill="url(#vdChromeLight)"
            fillOpacity="0.45"
          />
        </g>

        {/* Front Sweeping Deep Blue 3D Orbital Swoosh (Crosses Clearly Over Shield) */}
        <path
          d="M 22 148 C 18 188, 86 202, 158 166 C 206 142, 228 98, 212 66"
          stroke="url(#vdOrbitBlue)"
          strokeWidth="20"
          strokeLinecap="round"
          fill="none"
          filter="url(#vdDropShadow)"
        />
        {/* Inner Highlight on Blue Orbital Swoosh */}
        <path
          d="M 26 152 C 26 182, 88 194, 156 160 C 198 139, 220 100, 208 70"
          stroke="#93C5FD"
          strokeWidth="4.5"
          strokeLinecap="round"
          fill="none"
        />

        {/* Crisp 4-Point Metallic & Cyan Starburst at Top-Right */}
        <g transform="translate(192, 48)">
          <path
            d="M 0 -24 C 2 -6, 6 -2, 24 0 C 6 2, 2 6, 0 24 C -2 6, -6 2, -24 0 C -6 -2, -2 -6, 0 -24 Z"
            fill="#1E3A8A"
          />
          <path
            d="M 0 -20 C 1.5 -4, 4 -1.5, 20 0 C 4 1.5, 1.5 4, 0 20 C -1.5 4, -4 1.5, -20 0 C -4 -1.5, -1.5 -4, 0 -20 Z"
            fill="#FFFFFF"
          />
          <circle cx="0" cy="0" r="4.5" fill="#38BDF8" />
        </g>
      </svg>
    </div>
  );
};

export const VD_LOGO_SVG_STRING = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 240" width="512" height="512" fill="none">
  <defs>
    <linearGradient id="vdChromeLight" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#F8FAFC" />
      <stop offset="35%" stop-color="#CBD5E1" />
      <stop offset="70%" stop-color="#64748B" />
      <stop offset="100%" stop-color="#334155" />
    </linearGradient>
    <linearGradient id="vdSteelDark" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#475569" />
      <stop offset="50%" stop-color="#1E293B" />
      <stop offset="100%" stop-color="#0F172A" />
    </linearGradient>
    <linearGradient id="vdOrbitBlue" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#0F172A" />
      <stop offset="30%" stop-color="#1E3A8A" />
      <stop offset="65%" stop-color="#2563EB" />
      <stop offset="85%" stop-color="#60A5FA" />
      <stop offset="100%" stop-color="#1D4ED8" />
    </linearGradient>
  </defs>
  <rect width="240" height="240" fill="#FFFFFF" />
  <path d="M 38 118 C 26 72, 85 28, 156 36 C 198 40, 218 68, 206 104" stroke="#CBD5E1" stroke-width="12" stroke-linecap="round" fill="none" />
  <path d="M 42 112 C 34 74, 88 34, 154 40 C 192 44, 210 68, 200 100" stroke="#64748B" stroke-width="6" stroke-linecap="round" fill="none" />
  <path d="M 120 22 L 194 48 C 194 118, 172 174, 120 218 C 68 174, 46 118, 46 48 Z" fill="url(#vdSteelDark)" stroke="url(#vdChromeLight)" stroke-width="6" stroke-linejoin="round" />
  <path d="M 120 34 L 180 56 C 180 115, 160 163, 120 202 C 80 163, 60 115, 60 56 Z" fill="#FFFFFF" stroke="#94A3B8" stroke-width="3" stroke-linejoin="round" />
  <path d="M 66 64 L 90 64 L 112 138 L 134 64 L 154 64 L 120 172 L 102 172 Z" fill="url(#vdSteelDark)" />
  <path d="M 70 67 L 87 67 L 111 146 L 103 168 L 66 64 Z" fill="url(#vdChromeLight)" />
  <path d="M 116 64 L 152 64 C 176 64, 190 82, 190 114 C 190 146, 174 166, 148 166 L 116 166 Z M 136 82 L 136 148 L 147 148 C 162 148, 170 135, 170 114 C 170 93, 162 82, 147 82 Z" fill="url(#vdSteelDark)" />
  <path d="M 118 66 L 150 66 C 172 66, 185 82, 185 114 C 185 142, 171 160, 148 160 L 136 148 L 147 148 C 162 148, 170 135, 170 114 C 170 93, 162 82, 147 82 L 136 82 L 136 164 L 118 164 Z" fill="url(#vdChromeLight)" fill-opacity="0.45" />
  <path d="M 22 148 C 18 188, 86 202, 158 166 C 206 142, 228 98, 212 66" stroke="url(#vdOrbitBlue)" stroke-width="20" stroke-linecap="round" fill="none" />
  <path d="M 26 152 C 26 182, 88 194, 156 160 C 198 139, 220 100, 208 70" stroke="#93C5FD" stroke-width="4.5" stroke-linecap="round" fill="none" />
  <g transform="translate(192, 48)">
    <path d="M 0 -24 C 2 -6, 6 -2, 24 0 C 6 2, 2 6, 0 24 C -2 6, -6 2, -24 0 C -6 -2, -2 -6, 0 -24 Z" fill="#1E3A8A" />
    <path d="M 0 -20 C 1.5 -4, 4 -1.5, 20 0 C 4 1.5, 1.5 4, 0 20 C -1.5 4, -4 1.5, -20 0 C -4 -1.5, -1.5 -4, 0 -20 Z" fill="#FFFFFF" />
    <circle cx="0" cy="0" r="4.5" fill="#38BDF8" />
  </g>
</svg>`;

/**
 * Renders the VD Logo (or custom uploaded logoUrl) onto an offscreen canvas
 * and returns a clean PNG data URL for jsPDF and dynamic PWA favicons.
 */
export function renderLogoToPngDataUrl(customLogoUrl?: string, size: number = 300): Promise<string> {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      resolve('');
      return;
    }

    // Fill white background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, size, size);

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      // Draw image centered with object-contain aspect ratio
      const scale = Math.min(size / (img.width || size), size / (img.height || size));
      const w = (img.width || size) * scale;
      const h = (img.height || size) * scale;
      const x = (size - w) / 2;
      const y = (size - h) / 2;
      ctx.drawImage(img, x, y, w, h);
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = () => {
      resolve('');
    };

    if (customLogoUrl && customLogoUrl.trim() !== '') {
      img.src = customLogoUrl;
    } else {
      const svgBlob = new Blob([VD_LOGO_SVG_STRING], { type: 'image/svg+xml;charset=utf-8' });
      img.src = URL.createObjectURL(svgBlob);
    }
  });
}
